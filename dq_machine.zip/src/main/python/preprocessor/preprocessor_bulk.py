from pyspark import SparkConf
from pyspark import SparkContext

from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *

import sys
from datetime import *

from pyspark.rdd import *

import math

from collections import OrderedDict

# ############################
#
rtr = 1427#     RETAILER NUMBER!!!
old_struct = False
write_all = False
#
# ############################


# ############################
# ############################
#
# Preprocessor production version 1
#
# Date: June 30th 2017
#
# Authors:
#
#
#
# Execute with
#  spark-submit --master yarn --py-files ../db/jobstatus_db.py --num-executors 10 --driver-memory 10g --executor-memory 10g --executor-cores 16 --jars /hdpdata/santosh/elasticsearch-spark-20_2.11-5.1.2.jar preprocessor_bulk.py
#
# ############################
# ############################

def methods():
    listOfuncs = ["execute", "make_dept_aggregation","make_store_aggregation","make_brand_aggregation","update_headers","round_off","add_columns","make_item_aggregation","roundoff","dollar_scale","quiet_logs","preprocessor_bulk"]
    return
def execute(_dir,_inputyear,_all_dirs = []):
    if isinstance(_dir, basestring):
       _dir = [_dir]
    for this_dir in _dir:
        print('Directory: '+this_dir)

    process_output = True#write_all
    process_elasticsearch = False#write_all

    if _inputyear == -1:
        _inputyear = '/fullhistory/0'
    else:
        _inputyear = '/fullhistory/'+str(_inputyear)

    sqlContext = SQLContext(sc)
    
    # ###################
    # Determine the retailer number, date, and loadid
    # Note: this is the first file
    dir_struct = _all_dirs[0].split('/')
    retailer = '{:04d}'.format(int(dir_struct[6]))
    mydate = dir_struct[7]
    loadid = dir_struct[8]

    print('   Retailer: '+retailer)
    print('   Date:     '+mydate)
    print('   LoadID:   '+loadid)
    # ###################


    ##################
    ##
    ## Import the configuration for this retailer
    ## 
    ##################
    confFile = sc.textFile('/npd/configuration/retailerinput/rawdata/default.conf')
    confData = confFile.collect()
    rtrConfig = {}
    rtrConfig_rev = {}
    for d in confData:
        d = str(d.rstrip().lstrip())
        if d == '':
            continue
        d = d.split(' ')
        rtrConfig[d[0]] = d[1]
        rtrConfig_rev[d[1]] = d[0]

    # Update the maps with retailer specific settings
    confFile = sc.textFile('/npd/configuration/retailerinput/rawdata/retailer_config/Retailer_'+retailer+'.conf')
    confData = confFile.collect()
    for d in confData:
        d = str(d.rstrip().lstrip())
        if d == '':
            continue
        d = d.split(' ')
        rtrConfig[d[0]] = d[1]
        rtrConfig_rev[d[1]] = d[0]

    #############################


    print('Loaded configuration with settings:')
    for k,v in rtrConfig.items():
        print('Key: '+'{:30}'.format(k)+' '+str(v))

    ##################
    ##
    ## Define the data source
    ## loop over all directories
    ##
    ##################
    df = 0
    # Set the job_id in the db
    # Filter out all directories which do not exist in the database
    new_dir_list = []

    max_loadid = -1
    for this_dir in _all_dirs:
        dir_struct = this_dir.split('/')
        retailer = '{:04d}'.format(int(dir_struct[6]))
        mydate = dir_struct[7]
        loadid = dir_struct[8]
        
        #if int(mydate) < 2016073:
        #    continue
        
        if max_loadid < int(loadid):
            max_loadid = int(loadid)
        
        job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
        print(str(job_id)+' '+str(retailer)+' '+str(mydate)+' '+str(loadid)+' '+str(max_loadid))

        if job_id == -1: # no job found (probably no files)
            continue
        new_dir_list.append(this_dir)
        job.start_process('PRE_PROCESSOR')#sets the time stamp
        job.set_status_code_force('PRE_PROCESSOR','STATUS','STARTING_HDFS_LOAD')

        #if mydate == '2016073':
        #    break

    _all_dirs = new_dir_list
    print(_all_dirs)

    # Change the output for history to be the last_load id found
    if max_loadid != -1 and (int(_inputyear.split('/')[2])>2067 or int(_inputyear.split('/')[2])==0):
        _inputyear = '/fullhistory/'+str(max_loadid)
    print('Will write to: '+_inputyear+' in HDFS')

    new_dir_gz = []
    new_dir_dlm = []
    for this_dir in _all_dirs:
        new_dir_gz.append(this_dir+'/*.gz')
        new_dir_dlm.append(this_dir+'/*.dlm')

    if old_struct:
        new_dir_gz = _dir
        new_dir_dlm = _dir

    try: # first try to load the unzipped file type
        df = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "false").option("delimiter",rtrConfig['column_delimiter']).option("quote","\\").load(new_dir_dlm)
    except: # else try the gz file type
        df = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "false").option("delimiter",rtrConfig['column_delimiter']).option("quote","\\").option("codec","gzip").load(new_dir_gz)

    # ###############
    # Re-red if the number of columns is 1
    # Maybe because the delimiter is u'\u0001'
    # ###############
    if len(df.columns) < 2:
        rtrConfig['column_delimiter'] = u'\u0001'
        for this_dir in _all_dirs:
            dir_struct = this_dir.split('/')
            retailer = '{:04d}'.format(int(dir_struct[6]))
            mydate = dir_struct[7]
            loadid = dir_struct[8]

            job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
            job.set_status_code_force('PRE_PROCESSOR','STATUS','STARTING_HDFS_LOAD2')
        try: # first try to load the unzipped file type
            df = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "false").option("delimiter",rtrConfig['column_delimiter']).option("quote","\\").load(new_dir_dlm)
        except: # else try the gz file type
            df = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "false").option("delimiter",rtrConfig['column_delimiter']).option("quote","\\").option("codec","gzip").load(new_dir_gz)

    ##################
    ##
    ## Define the aggregations
    ##
    ##################

    agg_def = OrderedDict()
    agg_def['Units']     = "sum"
    agg_def['Dollars']   = "sum"
    if 'Null' not in rtrConfig['inventory_field']:
        agg_def['Inventory'] = "sum"
    if 'Null' not in rtrConfig['avecost_field']:
        agg_def['AveCost']   = "sum"
    agg_def['LineCount'] = "count"

    for k,v in agg_def.items():
        print('Aggregating '+ k +' with method '+v)

    ##################
    ##
    ## Define the columns
    ##
    ##################

    r = []

    # Generic dictionary dfdd
    r.append('_c'+rtrConfig['retailerid_field']+' as Retailer')
    r.append('_c'+rtrConfig['year_field']+' as Year')
    r.append('_c'+rtrConfig['month_field']+' as Month')
    r.append('_c'+rtrConfig['week_field']+' as Week')
    r.append('_c33 as DataFlag')
    # Dept/Class 
    r.append('_c'+rtrConfig['dept_field']+' as Dept')
    r.append('_c'+rtrConfig['class_field']+' as Class')
    # Items
    r.append('_c'+rtrConfig['item_field']+' as Item')
    r.append('_c'+rtrConfig['brand_field']+' as Brand')
    r.append('_c'+rtrConfig['description_field']+' as Description')
    #Store
    if 'Null' not in rtrConfig['storename_field']:
        r.append('_c'+rtrConfig['storename_field']+' as Store')
    else:
        r.append('_c23'+' as Store')
    r.append('_c'+rtrConfig['storezip_field']+' as Zip')
    r.append('_c'+rtrConfig['storestate_field']+' as State')
    if 'Null' not in rtrConfig['storeregion_field']:# and 'Null' not in rtrConfig['storeregion']:
        r.append('_c'+rtrConfig['storeregion_field']+' as Region')
    r.append('_c'+rtrConfig['units_field']+' as Units')
    r.append('_c'+rtrConfig['dollar_field']+' as Dollars')
    if 'Null' not in rtrConfig['inventory_field']:
        r.append('_c'+rtrConfig['inventory_field']+' as Inventory')
    if 'Null' not in rtrConfig['avecost_field']:
        r.append('_c'+rtrConfig['avecost_field']+' as AveCost')
    r.append('_c'+rtrConfig['linecount_field']+' as LineCount')

    df1 = df.selectExpr(r)

    # #############
    # We filter out the stuff we do not process in the factory
    # #############
    df1 = df1.filter('DataFlag!=0')

    # #############
    # Define how we make the nulls to be valid but null-taggable
    # #############
    blank_tag_str = 'NPD_blank'
    
    blank_dict = {'Dept':  blank_tag_str,
                  'Class': blank_tag_str,
                  'Store': blank_tag_str,
                  'Zip':   blank_tag_str,
                  'State': blank_tag_str,
                  'Item':  blank_tag_str,
                  'Description':  blank_tag_str,
                  'Brand': blank_tag_str,
                  'LineCount': blank_tag_str,
                  'Dollars': 0,
                  'Units': 0}
    if 'Null' not in rtrConfig['storeregion_field']:
        blank_dict['Region'] = blank_tag_str
    if 'Null' not in rtrConfig['inventory_field']:
        blank_dict['Inventory'] = 0
    if 'Null' not in rtrConfig['avecost_field']:
        blank_dict['AveCost'] = 0
    

    df1 = df1.na.fill(blank_dict)
    
    # #############
    # Do aggregations
    # #############

    for this_dir in _all_dirs:
        dir_struct = this_dir.split('/')
        retailer = '{:04d}'.format(int(dir_struct[6]))
        mydate = dir_struct[7]
        loadid = dir_struct[8]

        job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
        job.set_status_code_force('PRE_PROCESSOR','STATUS','STARTING_HDFS_AGG')

    print('Store aggregation')
    df_store = make_store_aggregation(df1,agg_def,rtrConfig)

    print('Dept aggregation')
    df_dept = make_dept_aggregation(df1,agg_def,rtrConfig)

    print('Item aggregation')
    df_item = make_item_aggregation(df1,agg_def,rtrConfig)

    print('Brand aggregation')
    df_brand = make_brand_aggregation(df1,agg_def,rtrConfig)

    if process_output:
        found_errors = 'HDFS_'
        found_errors_count = 0
        year = 0
        for this_dir in _all_dirs:
            if year == 0:
                year = mydate[0:4]
            dir_struct = this_dir.split('/')
            retailer = '{:04d}'.format(int(dir_struct[6]))
            mydate = dir_struct[7]
            loadid = dir_struct[8]
            job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
            job.set_status_code_force('PRE_PROCESSOR','STATUS','STARTING_HDFS_WRITE')

        print('Performing the HDFS write operations: '+str(datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")))
        #try:
        print('Store writing')
        df_store.repartition(1).write.format("com.databricks.spark.csv").option("header", "true").option("delimiter", "|").save('/npd/processed/data/retailerinput/'+retailer+'/stores'+_inputyear)
        #except:
        #    print('    Store writing failed, file is already written to HDFS: '+'/npd/processed/data/retailerinput/'+retailer+'/stores'+_inputyear)
        #    found_errors_count += 1
        #    found_errors = found_errors+'S'
        
        try:
            print('Dept writing')
            df_dept.repartition(1).write.format("com.databricks.spark.csv").option("header", "true").option("delimiter", "|").save('/npd/processed/data/retailerinput/'+retailer+'/depts'+_inputyear)
        except:
            print('    Dept writing failed, file is already written to HDFS: '+'/npd/processed/data/retailerinput/'+retailer+'/depts'+_inputyear)
            found_errors_count += 1
            found_errors = found_errors + 'D'

        try:
            print('Items writing')
            df_item.repartition(1).write.format("com.databricks.spark.csv").option("header", "true").option("delimiter", "|").save('/npd/processed/data/retailerinput/'+retailer+'/items'+_inputyear)
        except:
            print('    Items writing failed, file is already written to HDFS: '+'/npd/processed/data/retailerinput/'+retailer+'/items'+_inputyear)
            found_errors_count += 1
            found_errors = found_errors+'I'

        try:
            print('Brand writing')
            df_brand.repartition(1).write.format("com.databricks.spark.csv").option("header", "true").option("delimiter", "|").save('/npd/processed/data/retailerinput/'+retailer+'/brand'+_inputyear)
        except:
            print('    Brand writing failed, file is already written to HDFS: '+'/npd/processed/data/retailerinput/'+retailer+'/brand'+_inputyear)
            found_errors_count += 1
            found_errors = found_errors+'B'

        print('Completed: '+str(datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")))

        # ############
        if process_elasticsearch:
            es_conf = {"es.nodes" : "http://lslhdpcd1.npd.com","es.port" : "9200","es.resource" : "this is set below","es.index.auto.create": "yes"}
            es_name = 'reva_'
            es_type = '/Retailer'

            # ############
            # Check ElasticSearch status, we do not write twice ... 

            es_db_status = ''
            for this_dir in _all_dirs:
                dir_struct = this_dir.split('/')
                retailer = '{:04d}'.format(int(dir_struct[6]))
                mydate = dir_struct[7]
                loadid = dir_struct[8]

                job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
                this_status = job.get_status_force('ELASTICSEARCH_STATUS')
                if es_db_status == '' or this_status=='COMPLETE':
                    es_db_status = this_status
            
            if es_db_status == 'NOT_STARTED':
                print('Performing the ElasticSearch write operations: '+str(datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")))
                for this_dir in _all_dirs:
                    dir_struct = this_dir.split('/')
                    retailer = '{:04d}'.format(int(dir_struct[6]))
                    mydate = dir_struct[7]
                    loadid = dir_struct[8]
                    job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
                    job.set_status_code_force('PRE_PROCESSOR','STATUS','STARTING_ELASTIC_WRT')
                    job.start_process('ELASTICSEARCH')

                found_errors = found_errors+'_ES_'
                found_es_errors_count = 0
                try:
                    print('Store writing')
                    es_conf["es.resource"] = es_name+'stores'+es_type
                    rdd = df_store.rdd.map(lambda row: (None, row.asDict()))        
                    rdd.saveAsNewAPIHadoopFile(path='-',outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",keyClass="org.apache.hadoop.io.NullWritable",valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",conf=es_conf)
                except:
                    print('    Store elastic-seach load error')
                    found_errors_count += 1
                    found_es_errors_count += 1
                    found_errors = found_errors+'S'

                try:
                    print('Dept writing')
                    es_conf["es.resource"] = es_name+'depts'+es_type
                    rdd = df_dept.rdd.map(lambda row: (None, row.asDict()))
                    rdd.saveAsNewAPIHadoopFile(path='-',outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",keyClass="org.apache.hadoop.io.NullWritable",valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",conf=es_conf)
                except:
                    print('    Dept elastic-search load error')
                    found_errors_count += 1
                    found_es_errors_count += 1
                    found_errors = found_errors+'D'

                try:
                    print('Items writing')
                    es_conf["es.resource"] = es_name+'items'+es_type
                    rdd = df_item.rdd.map(lambda row: (None, row.asDict()))
                    rdd.saveAsNewAPIHadoopFile(path='-',outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",keyClass="org.apache.hadoop.io.NullWritable",valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",conf=es_conf)
                except:
                    print('    Items elastic-search load error')
                    found_errors_count += 1
                    found_es_errors_count += 1
                    found_errors = found_errors+'I'

                try:
                    print('Brand writing')
                    es_conf["es.resource"] = es_name+'brands'+es_type
                    rdd = df_brand.rdd.map(lambda row: (None, row.asDict()))
                    rdd.saveAsNewAPIHadoopFile(path='-',outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",keyClass="org.apache.hadoop.io.NullWritable",valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",conf=es_conf)
                except:
                    print('    Brand elastic-search load error')
                    found_errors_count += 1
                    found_es_errors_count += 1
                    found_errors = found_errors+'B'
    
                print('Completed: '+str(datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")))
                
                for this_dir in _all_dirs:
                    dir_struct = this_dir.split('/')
                    retailer = '{:04d}'.format(int(dir_struct[6]))
                    mydate = dir_struct[7]
                    loadid = dir_struct[8]

                    job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
                    if found_es_errors_count == 0:
                        job.end_process('ELASTICSEARCH','COMPLETE')
                    else:
                        print(found_es_errors_count)
                        print(found_errors)
                        job.end_process('ELASTICSEARCH','CRASHED')
            else:
                print('Skipping elasticsearch writing: already completed')
                for this_dir in _all_dirs:
                    dir_struct = this_dir.split('/')
                    retailer = '{:04d}'.format(int(dir_struct[6]))
                    mydate = dir_struct[7]
                    loadid = dir_struct[8]
                    job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
                    job.end_process('ELASTICSEARCH','COMPLETE_OVERWRITE_STOPPED')
                    job.set_status_code_force('ELASTICSEARCH','STATUS','COMPLETE_OVERWRITE_STOPPED')
        else:
            print('Skipping elasticsearch writing: for testing')

        # #################
        # Set the end-process flag in the DB
        for this_dir in _all_dirs:
            dir_struct = this_dir.split('/')
            retailer = '{:04d}'.format(int(dir_struct[6]))
            mydate = dir_struct[7]
            loadid = dir_struct[8]
            job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
            
            if found_errors_count == 0:
                job.end_process('PRE_PROCESSOR','COMPLETE')
            else:
                job.end_process('PRE_PROCESSOR',found_errors)

    else:
        print('Skipping Elastic-search and HDFS write steps')
        #df_store.show()
        #df_dept.show()
        #df_item.show()
        #df_brand.show()

        for this_dir in _all_dirs:
            dir_struct = this_dir.split('/')
            retailer = '{:04d}'.format(int(dir_struct[6]))
            mydate = dir_struct[7]
            loadid = dir_struct[8]
            job_id = job.set_jobid(retailer,mydate[0:4],mydate[4:6],mydate[6:7],loadid,_quiet=True)
            job.end_process('PRE_PROCESSOR','DID_NOT_TRY_TO_WRITE')


    print("Success!!")



def make_store_aggregation(_df,_agg,_config):
    df = 0
    # fix typo for this
    if 'Null' in _config['storeregion_field']:# or 'Null' in _config['storeregion']:
        df = _df.groupby('Retailer',
                         'Year',
                         'Month',
                         'Week',
                         'Store',
                         'Zip',
                         'State').agg(_agg)
    else:
        df = _df.groupby('Retailer',
                         'Year',
                         'Month',
                         'Week',
                         'Store',
                         'Zip',
                         'State',
                         'Region').agg(_agg)

    udf_roundoff = udf(roundoff, FloatType())
    udf_dollar_scale = udf(dollar_scale, FloatType())

    ##################
    ##
    ## Perform Rounding and scaling
    ##
    ##################
    variable = 'sum(Dollars)'
    if _config['dollar_scale'] == '100':
        df = df.withColumn(variable,udf_dollar_scale(variable))
    df = df.withColumn(variable,udf_roundoff(variable))

    df = add_columns(df)

    return(update_headers(df))

def update_headers(_df):
    _df = _df.withColumnRenamed("sum(Dollars)","sum_Dollars")
    _df = _df.withColumnRenamed("sum(Units)","sum_Units")
    _df = _df.withColumnRenamed("sum(Inventory)","sum_Inventory")
    _df = _df.withColumnRenamed("sum(AveCost)","sum_AveCost")
    _df = _df.withColumnRenamed("count(LineCount)","count_LineCount")

    try:
        _df = _df.na.fill({'Item': 0})
    except:
        print('cannot null Item as integer')

    print('show')
    #_df.take(10).show()
    print('show schema')
    _df.printSchema()

    return(_df)



def make_dept_aggregation(_df,_agg,_config):
    df = _df.groupby('Retailer',
                     'Year',
                     'Month',
                     'Week',
                     'Dept',
                     'Class').agg(_agg)

    udf_roundoff = udf(roundoff, FloatType())
    udf_dollar_scale = udf(dollar_scale, FloatType())

    ##################
    ##
    ## Perform Rounding and scaling
    ##
    ##################
    variable = 'sum(Dollars)'
    if _config['dollar_scale'] == '100':
        df = df.withColumn(variable,udf_dollar_scale(variable))
    df = df.withColumn(variable,udf_roundoff(variable))

    df = add_columns(df)

    return(update_headers(df))


def add_columns(_df, _includeYMW = True):

    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    print(timestamp)
 
    _df = _df.withColumn('@timestamp',lit(timestamp))
 
    if _includeYMW:
        _df = _df.withColumn('YMW',lit(_df.Year*1000+_df.Month*10+_df.Week))
        _df = _df.withColumn('MW',lit(_df.Month*10+_df.Week))

    return(_df)


def make_brand_aggregation(_df,_agg,_config):
    df = _df.groupby('Retailer',
                     'Year',
                     'Month',
                     'Week',
                     'Brand').agg(_agg)

    udf_roundoff = udf(roundoff, FloatType())
    udf_dollar_scale = udf(dollar_scale, FloatType())

    ##################
    ##
    ## Perform Rounding and scaling
    ##
    ##################
    variable = 'sum(Dollars)'
    if _config['dollar_scale'] == '100':
        df = df.withColumn(variable,udf_dollar_scale(variable))
    df = df.withColumn(variable,udf_roundoff(variable))

    df = add_columns(df)

    return(update_headers(df))


def make_item_aggregation(_df,_agg,_config):
    df = _df.groupby('Retailer',
                     'Year',
                     'Month',
                     'Week',
                     'Dept',
                     'Class',
                     'Item',
                     'Brand',
                     'Description').agg(_agg)

    udf_roundoff = udf(roundoff, FloatType())
    udf_dollar_scale = udf(dollar_scale, FloatType())

    ##################
    ##
    ## Perform Rounding and scaling
    ##
    ##################
    variable = 'sum(Dollars)'
    if _config['dollar_scale'] == '100':
        df = df.withColumn(variable,udf_dollar_scale(variable))
    df = df.withColumn(variable,udf_roundoff(variable))

    df = add_columns(df,True)
    df = update_headers(df)
    df = df.filter('sum_Dollars>1000 OR sum_Units>100')

    return(df)



##################
##
## Rounding Function
##
##################
def roundoff(num):
    return (math.ceil(num*100)/100)

##################
##
## Dollars/AveCost Scaling Function
##
##################
def dollar_scale(num):
    return float(num/100.)


# ##################################
# ##################################
#
# Sabbir's code to quieten the output
#
# ##################################
# ##################################
def quiet_logs( sc ):
    logger = sc._jvm.org.apache.log4j
    logger.LogManager.getLogger("org"). setLevel( logger.Level.ERROR )
    logger.LogManager.getLogger("akka").setLevel( logger.Level.ERROR )
# ##################################
# ##################################

def preprocessor_bulk():
    from db import jobstatus_db

    conf = SparkConf()
    global sc
    sc = SparkContext(conf=conf)
    quiet_logs(sc)
    #sc.addPyFile('db/jobstatus_db.py')

    #from db import jobstatus_db
    # ###################
    # Set up the DB connection
    print('setting up db')
    global job
    job = jobstatus_db()
    job.set_hostname('lslhdpcd1.npd.com')
    job.set_database('PACEDQ')
    job.set_table('JOB_STATUS')
    job.set_primary_key_name('JOB_ID')
    job.get_setup()
    # ####################

    #define array
    year = -1
    my_dirs = job.get_waiting_history(rtr,_year=year,_filetype='fgo')
    print(my_dirs)
    
    # set the code going
    
    if old_struct:
        execute(['/npd/rawdata/data/retailerinput/retailer_'+str(rtr)+'/'+str(rtr)],year,my_dirs)
    else:
        execute(my_dirs,year,my_dirs)


# FOR BULK TURN THIS OFF

#print('Script Running',sys.argv[0],'with', len(sys.argv)-1, 'arguments')
#print('Argument List:', str(sys.argv[1:]))
#execute(sys.argv[1])

