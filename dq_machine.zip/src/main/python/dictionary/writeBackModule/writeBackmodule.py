from operator import is_not
from functools import partial
import hdfs
from hdfs import Config

class writeBackmodule(object):

	def __init__(self,):
		self.config = None
		return
	def __str__(self,):
		return
	def load(self,):
		return
	def insert(self,):
		return
	def update(self,):
		return
	def delete(self,):
		return
	def isExist(self,):
		return True
	def setConfigvariables(self, config):
		self.config = config
		
