import sys
import os
from hdfsFileDiscovery import todaysKey
from hdfsFileDiscovery import rangeOfdate
from updatePositems import startReadingfromhive
from processingUnit import hiveInit
from processingUnit2 import startReadingfromhdfs
from processingUnit import quiet_logs
from hdfsFileDiscovery import globalMain
from processingUnit2 import getColumnsname
from updatePositems import getColumnsnameods
from processingUnit2 import columnRenaming
from processingUnit2 import getLastfilenumber
import pyspark
import pyspark.sql.functions as  psf
from pyspark.sql.types import *
from pyspark.sql.types import DoubleType
import os
import sys
import datetime
from collections import defaultdict
from pyspark.sql import Row
import MySQLdb
from py4j.protocol import Py4JJavaError
from processingUnit import executeScripts
from processingUnit import hiveExecutecommands
from processingUnit2 import addingPartitionersnapshot
from pyspark.sql.functions import col
from hdfsFileDiscovery import getFilelist
from hivewritebackModule import  hivewriteback

def filteredQuery(snapshotRdd, query, odsitem, spark, bList):
	businessid = "businessid" if odsitem is 1 else "business_id"
	bidRdd = snapshotRdd.select("business_id","partitioner").where(snapshotRdd.business_id != 0).distinct() if odsitem is 0 else snapshotRdd.select("businessid","itemid").where(snapshotRdd.itemid != 0).distinct()
	#bidRdd.select("business_id").distinct().show()
	bidRdd = bidRdd.where(col(businessid).isin(bList) == True)
	#bidRdd.select(businessid).show()
	bidlist = [str(each) for each in bidRdd.collect()]
	query = query + " where " + businessid + "in (" + ",".join(bidlist) + ")"
	return bidRdd, query
def getPartitionandBusinessset(bidRdd):
	listOfbusinessAndpart = bidRdd.rdd.map(lambda x: (x.business_id,x.partitioner)).collect()
	listOfbusinessAndpart = zip(*listOfbusinessAndpart)
	businessSet = set(listOfbusinessAndpart[0])
	partitionSet = set(listOfbusinessAndpart[1])
	return (businessSet, partitionSet)
def fixDatatype(rdd = None, tupleOfcol = []):
	for each in tupleOfcol:
		rdd = rdd.withColumn(each[0],rdd[each[0]].cast(each[1]))
	return rdd
def filterBasefiles(listOffiles, lastfileNumber = 'part-000000.bz2'):
	try:
		for each in listOffiles:
			if(each.split("/")[-1] >= lastfileNumber):
				listOffiles.remove(each)
	except ValueError as ve:
		print "Gettign a value error " + str(ve) 
	return listOffiles
def isSnapshotfiles(dates, listOfdates):
	for each in listOfdates:
		if each == dates:
			return True
	return False
def loadingData(data_path = None , baseDir = None, spark = None, readHive = 1, odsitem = 1, fileType = 0, ranges = 0,businessList = None,delta = 0, filtering  = 1, configOb = None, debug = True):
	if len(sys.argv) == 2:
        	print("Usage: snapshotdetector number of days" + str(sys.argv[1]))
        	ranges = int(sys.argv[1])
        quiet_logs(sc_ = spark)
        hc, sqlc = hiveInit(sc_ = spark)
        groupedDict = globalMain(pathName = data_path,sc_= spark)
	if odsitem is 1:
	        print("start reading snapshots for odsitem table")
	else:
		print ("start reading snapshots for posoutlet table")
        date_list, hr = rangeOfdate(ranges) if ranges is not 0 else todaysKey(delta = configOb.delta)
	print "so total dates: " + str(date_list)
        totalsnapShots = sqlc.createDataFrame(spark.emptyRDD(),StructType([]))
        fileList = []
	fileList_for_base = []
	configOb.processingDate = date_list +" "+ str(hr) if isinstance(date_list, str) is True else date_list[0] +" " + str(hr)
        for each in groupedDict.iteritems():
                if isSnapshotfiles(each[0].split()[0] , date_list) is False:
			fileList_for_base = fileList_for_base +  each[1]
                        continue
		print each[1]
                fileList = fileList + each[1]
        if len(fileList ) is 0:
                print "Its empty exiting"
                exit(0)
        print ("Get the filtered files to read")
        needToread, last_file_num, fn = getLastfilenumber(fileList, ft = fileType )
	# Need to handle the scenario of different source for files 
	print "file list len: " + str(len(needToread)) + " " + str(last_file_num)
	fileList_for_base = filterBasefiles(fileList_for_base, lastfileNumber = fn)
        print ("start reading snapshot files")
        stringedList = ",".join(needToread)
	if debug is True:
		print "List of files gonna be loaded: " + str(stringedList)
	table_name = configOb.hivedbOb.get_dbName(index = 0) + "." + configOb.hivedbOb.get_tabNames(dbName_ = configOb.hivedbOb.get_dbName(index = 0), index = 2 if odsitem is 0 else 3 )

	query_for_base = "select itemid, businessid, subcategoryn, itemnumber, unitspackage,fld01, fld02, fld03, fld04, fld05, fld06, fld07, fld08, fld09, fld10, fld11, fld12, fld13, fld14, fld15, fld16, fld17, fld18, fld19, fld20, fld21, fld22, fld23, fld24, fld25, fld26, fld27, fld28, fld29, fld30, fld31, fld32, fld33, fld34, fld35, fld36, fld37, fld38, fld39, fld40, fld41, fld42, fld43, fld44, fld45, fld46, fld47, fld48, fld49, fld50, fld51, fld52, fld53, fld54, fld55, fld56, fld57, fld58, fld59, fld60, fld61, fld62, fld63, fld64, fld65, fld66, fld67, fld68, fld69, fld70, fld71, fld72, fld73, fld74, fld75, fld76, fld77, fld78, fld79, fld80, fld81, fld82, fld83, fld84, fld85, fld86, fld87, fld88, fld89, fld90, fld91, fld92, fld93, fld94, fld95, fld96, fld97, fld98, fld99, status, added, updated, vfld01, vfld02, vfld03, vfld04, vfld05, country_code, groupitemid, parentitemid, parentitemid_status, outletitem_map_change_date, lockdown_status from " + table_name if odsitem is 1 else  "select " +",".join(getColumnsname()) + ", partitioner  from " + table_name   
	# fileList should be replaced by needToread list after testing
        snapshotRdd = startReadingfromhdfs(sqlc = sqlc, listOffiles = needToread, spark = spark,multi = 0)# multi can be 2 
	if debug is True:
		print "snapshot data count before businesswise filtering: " + str(snapshotRdd.count())

	#query = filteredQuery(snapshotRdd,query,odsitem)
	scriptPath = 'src/main/python/dictionary/fileSource/creationScripts/'
	scriptPath = scriptPath + 'createodsitem.sql' if odsitem is 1 else scriptPath + 'createOutlet.sql' 
	#executeScripts(scriptPath,hc,sqlc,spark):
	listofC = getColumnsname() if odsitem is 0 else getColumnsnameods()
	cols = columnRenaming(listofC) 
	snapshotRdd = snapshotRdd.selectExpr(cols) #if odsitem is 0 else snapshotRdd.selectExpr(cols)
	listofC += ["partitioner"] if odsitem is 0 else []
	cols = columnRenaming(listofC) if odsitem is 0 else cols
	snapshotRdd = fixDatatype(snapshotRdd, tupleOfcol = [("posoutlet","long"),("sku","long"),("itemid","long"),("business_id","int"),("poi_id","long")]) if odsitem is 0 else snapshotRdd
	snapshotRdd = fixDatatype(snapshotRdd, tupleOfcol = [("itemid","long"),("businessid","long"),("subcategoryn","long"),("itemnumber","long")]) if odsitem is 1 else snapshotRdd
	snapshotRdd = snapshotRdd.where(snapshotRdd.business_id.isin(configOb.businessSets)) if configOb is not None and odsitem is 0 else snapshotRdd
	snapshotRdd = snapshotRdd.where(snapshotRdd.businessid.isin(configOb.businessSets)) if configOb is not None and odsitem is 1 else snapshotRdd
	snapshotRddwithPartition,itemidRdd = addingPartitionersnapshot(snapshotRdd, spark, sqlc ) if odsitem is 0 else (snapshotRdd,None)
	snapshotRdd = snapshotRdd.repartition(120)
	if debug is True:
		print "snapshot data count: " + str(snapshotRdd.count())
		if snapshotRdd != snapshotRddwithPartition:
			print "snapshot history data count: " + str(snapshotRddwithPartition.count())
		else:
			print "same data count for identical RDD"
	bidRdd, query = filteredQuery(snapshotRddwithPartition, query_for_base, odsitem, spark, businessList)
	#listOffiles = bidRdd.distinct().rdd.map(lambda x : '/apps/hive/warehouse/dqdictionaryhivedb.db/uniqueodsposoutlet2_int/business_id=' + str(x.business_id)).collect() if odsitem is 0 else bidRdd.distinct().map(lambda x : '/apps/hive/warehouse/dqdictionaryhivedb.db/uniqueodspositems2_int/BUSINESSID=' + str(x.businessid)).collect()
	print "getting the list of files"
	listOffiles = []
	fileList2 = getFilelist(listOffiles,sc_= spark) if odsitem is 0 else []
	fileListset = set(fileList2)
	businessSet,partitionSet =  getPartitionandBusinessset(bidRdd) if odsitem is 0 else (None,None)
        listOffiles = bidRdd.rdd.map(lambda x : Row(path_name = '/apps/hive/warehouse/dqdictionaryhivedb.db/uniqueodsposoutlet2_int/business_id=' + str(x.business_id) + '/partitioner=' + x.partitioner, business_id = x.business_id, parititioner = x.partitioner)).toDF() if odsitem is 0 else bidRdd.rdd.map(lambda x : Row(path_name = '/apps/hive/warehouse/dqdictionaryhivedb.db/uniqueodspositems2_int/BUSINESSID=' + str(x.businessid),businessid = x.businessid)).toDF()
	listOffiles = listOffiles.where(col("path_name").isin(fileListset) == True).rdd.map(lambda x: x.path_name).collect() if len(fileListset) is not 0 else listOffiles.rdd.map(lambda x: x.path_name).collect()
	#print "List of files need to be overwrite: " + str(listOffiles)
	#print "length of the file list: " + str(len(listOffiles))
	#baseDir = listOffiles if len(listOffiles) is not 0 else baseDir
	print "Start loading the base dictionary"
	baseDict = startReadingfromhdfs(sqlc = sqlc,listOffiles = baseDir if baseDir is not None else fileList_for_base , multi = 2 if  baseDir is None else 1, spark = spark) if readHive is 0 else startReadingfromhive(query = query_for_base, hc = hc, sqlc = sqlc,spark = spark)
	baseDict = baseDict.selectExpr(cols) if readHive is 0 else baseDict
	baseDict = baseDict.where(baseDict.business_id != 0) if odsitem is 0 else baseDict #col("business_id").isin(businessSet) & col("partitioner").isin(partitionSet))
	#hiveExecutecommands("drop table " += "uniqueodspositems_ext" if odsitem is 1 else "uniqueodsposoutlet_ext",hive_context = hc )
	baseDict = fixDatatype(baseDict,tupleOfcol = [("posoutlet","long"),("sku","long"),("itemid","long"),("poi_id","long"),("business_id","int")]) if odsitem is 0 else baseDict
	baseDict = fixDatatype(baseDict, tupleOfcol = [("itemid","long"), ("businessid","long"),("subcategoryn","long"),("itemnumber","long")]) if odsitem is 1 else baseDict
	#snapshotRdd = fixDatatype(snapshotRdd, tupleOfcol = [("posoutlet","long"),("sku","long"),("itemid","long"),("business_id","int"),("poi_id","long")]) if odsitem is 0 else snapshotRdd
	#snapshotRdd = fixDatatype(snapshotRdd, tupleOfcol = [("itemid","long"),("businessid","long"),("subcategoryn","long"),("itemnumber","long")]) if odsitem is 1 else snapshotRdd
	#baseDict.printSchema()	
	print "size of the loaded base dictionary is: " + str(baseDict.count())
	return snapshotRdd, baseDict,fileList, listOffiles, businessSet, partitionSet, itemidRdd, snapshotRddwithPartition

#End of the writebacke functionality should have been a class#
