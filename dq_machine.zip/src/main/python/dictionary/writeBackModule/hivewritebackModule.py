# hive write Back module
from writeBackmodule import writeBackmodule
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark import SparkContext
from pyspark import SparkConf
from collections import deque
from hdfsFileDiscovery import deletePath

class hivewriteback(writeBackmodule):
	def __init__(self,config_ = None, mappedDic = None,spark = None):
		self.config = config_
		self.itemidDict = mappedDic
		self.tableName = None
		self.stack1 = deque()
		self.stack2 = deque()
		self.spark = spark
		self.posoutlet_tup = ["poi_id bigint" ,"business_id int" ,"posoutlet bigint" ,"outletdivision int"  ,"outletdepartment int" ,"outletsubdepartment int" ,"outletclass int" ,"outletsubclass int" ,"outletbrand string" ,"outletitemnumber string","outletdescription string" ,"outletbrandmatch string" ,"outletitemnumbermatch string" ,"outletdescriptionmatch string" ,"sku int" ,"manufacturercodetype string" ,"manufacturercode bigint" ,"zzzppmonthfrom int" ,"zzzppmonthto int" , "zzzppmonthlastused int" ,"itemid bigint" ,"itemtype string" ,"price int" ,"manufacturercodestatus int" ,"loadid int" ,"status int" ,"added timestamp" ,"updated timestamp","ppweekfrom int" ,"ppweekto int" ,"ppweeklastused int" ,"matched_country_code int" ,"previous_poiid int" ,"include_data_ppmonthfrom int" ,"include_data_ppweekfrom int" ,"manufacturercodematch int" ,"skumatch int" , "unitofmeasure string" ,"packsize string" ,"manufacturername string" ,"manufacturernamematch string" ,"privatelabel string" ,"outletdescriptionsupplement string" ,"total_confidence_score string" , "parent_poiid bigint" ,"parent_poiid_status string"]
		self.odsitem_tup = ["itemid bigint","businessid int","subcategoryn bigint", "itemnumber bigint","unitsperpackage int","fld01 bigint","fld02 bigint","fld03 bigint","fld04 bigint","fld05 bigint","fld06 bigint","fld07 bigint","fld08 bigint","fld09 bigint","fld10  bigint","fld11   bigint","fld12 bigint","fld13  bigint","fld14  bigint","fld15 bigint","fld16 bigint","fld17 bigint","fld18 bigint","fld19 bigint","fld20 bigint","fld21  bigint","fld22  bigint","fld23  bigint","fld24 bigint","fld25 bigint","fld26 bigint","fld27 bigint","fld28 bigint","fld29 bigint","fld30 bigint","fld31 bigint","fld32 bigint","fld33 bigint","fld34 bigint","fld35 bigint","fld36 bigint","fld37 bigint","fld38 bigint","fld39 bigint","fld40 bigint","fld41 bigint","fld42 bigint","fld43 bigint","fld44 bigint","fld45 bigint","fld46 bigint","fld47 bigint","fld48 bigint","fld49 bigint","fld50 bigint","fld51 bigint","fld52 bigint","fld53 bigint","fld54 bigint","fld55 bigint","fld56 bigint","fld57 bigint","fld58 bigint","fld59 bigint","fld60 bigint","fld61 bigint","fld62 bigint","fld63 bigint","fld64 bigint","fld65 bigint","fld66 bigint","fld67 bigint","fld68 bigint","fld69 bigint","fld70 bigint","fld71 bigint","fld72 bigint","fld73 bigint","fld74 bigint","fld75 bigint","fld76 bigint","fld77 bigint","fld78 bigint","fld79 bigint","fld80  bigint","fld81 bigint","fld82 bigint","fld83 bigint","fld84 bigint","fld85 bigint","fld86 bigint","fld87 bigint","fld88 bigint","fld89 bigint","fld90 bigint","fld91  bigint","fld92 bigint","fld93  bigint","fld94 bigint","fld95 bigint","fld96 bigint","fld97 bigint","fld98 bigint","fld99  bigint","status int","added timestamp","updated timestamp","vfld01 int","vfld02 int","vfld03 int","vfld04 int","vfld05 int","country_code int","groupitemid bigint","parentitemid bigint","parentitemid_status int","outletitem_map_change_date timestamp","lockdown_status int"]
		return
	def __str__(self,):
		print "it is hive writback module"
		return
	def hiveUpdate(self,recievedRdd):
		#self.hive_context.sql('Update ' + self.setTableName + ' set ')
		print ("Look for delete reinsert")
		return
	def setTablename(self, tableName = None):
		if (tableName is None):
			print "table name is null nothing to set"
			raise ValueError
		print ("Set the table name")
		self.tableName = tableName
		return
	def writeIntohdfs(self, rdd, pathName = None,fixType = True,odsitem = 1):
		deletePath(pathName, self.spark)
	 	rdd = rdd.repartition(400)
		type_ = self.posoutlet_tup if odsitem is 0 else self.odsitem_tup
  		rdd = self.fixDatatype(rdd, type_) if fixType is True else rdd
		rdd.write.format("com.databricks.spark.csv").option("header","true").option("delimiter","|").option("inferSchema","true").option("codec","bzip2").option("quote","\\").option("treatEmptyValuesAsNulls","true").option("nullValue",None).save(pathName)
		return 
###################### End of hive update operation ###########################################
	def getbusinessParts(self,businessId):
		businessId = int(businessId)
		if businessId >= 50 and businessId <= 55:
			return 55
		elif businessId >= 56 and businessId <= 60:
			return 60
		elif businessId >= 61 and businessId <= 65:
			return 65
		elif businessId >= 66 and businessId <= 70:
			return 70
		elif businessId >= 71 and businessId <= 75:
 			return 75
		elif businessId >= 76 and businessId <= 80:
			return 80
		elif businessId >= 81 and businessId <= 85:
			return 85
		elif businessId >= 86 and businessId <= 90:
			return 90
		elif businessId >= 91 and businessId <= 110:
			return 110
		elif businessId >= 111 and businessId <= 130:
			return 130
		elif businessId >= 131 and businessId <= 150:
			return 150
		else:
			return 172
		return -1

###################### hive insert operation #######################################
	def setStacktooperate(self,):
		if self.stack1.usage is True:
			self.operatingStack = self.stack1
			self.restingStack = self.stack2
			return True
		if self.stack2.usage is True:
			self.operatingStack = self.stack2
			self.restingStack = self.stack1
			return True
		return	False
	def fixDatatype(self, rdd  = None, tupleOfcol = []):
		for each in tupleOfcol:
			each = each.split(" ")
			rdd = rdd.withColumn(each[0], rdd[each[0]].cast(each[1]))
		return rdd
	def insertIntopartitiontable(self,partitionFiles = None, dictRdd = None , append = 0, table_name = 'dqdictionaryhivedb.uniqueodsposoutlet2_int'):
		writeMode = "overwrite" if append is 0 else "append"
		#self.spark.hadoopConfiguration.set("orc.enable.summary-metadata","false")
		dictRdd = dictRdd.repartition("business_id","partitioner")
		dictRdd.write.mode(writeMode).partitionBy("business_id","partitioner").format("orc").saveAsTable(table_name)
		return
	def insert(self,recievedRdd):
		recieveRdd.registerTempTable('newInserts')
		#partitiondict = loadPickledFile(fileName = 'pickledStack')	
		dataList = recievedRdd.collect()
		self.newitemIdDict = {}
		for each in dataList:
			partItem = 'default_partition'
			if self.operatingStack.size() is not 0:
				partItem = self.operatingStack.peek()
				self.restingStack.append(self.operating.peek())
				self.operatingStack.pop()
				
			else:
				self.operatingStack.usage = False
				self.restingStack.usage = True
				self.setStacktooperate()
				partItem = self.operatingStack.peek()
				self.restingStack.append(self.operating.peek())
				self.operatingStack.pop()

			if self.setTableName.find( 'odsposoutletitems') is not -1:
				self.hive_context.sql('insert into ' + self.setTableName + ' partition (( partitioner = ' + partItem + ')) values ' + (each.poi_id,each.bussiness_id,each.posoutlet,each.outletdivision,each.outletdepartment,each.outletclass,each.outletbrand, each.outletitemnumber,each.outletdescription, each.outletbrandmatch,each.manufacturedcode,each.sku,each.itemid, each.itemtype,each.price, each.manufacturercodestatus, each.loadid, each.status, each.added, each.updated, each.matched_country_code, each.previous_poiid, each.parent_poiid, each.parent_poiid_status, partItem))
				self.itemidDict[long(each.itemid)] = partItem
			elif self.setTableName.find('odsitems') is not -1:
				self.hive_context.sql('insert into ' + self.setTableName + ' partition  ( business_parts = '+ self.getbusinessParts(each.business_id) + ')  values ' + (each.itemid, each.bussiness_id,each.subcategoryn, each.itemnumber, each.unitsperpackage,each.status, each.added, each.updated, each.country_code))
				self.itemidDict[long(each.itemid)] = partItem

		self.dictionaryPartitionWriteB()
		#self.createPickledFile(fileName = 'pickledStack',Ob = partitiondict)
		spark.catalog.dropTempView('newInserts')
	
		return 

########################### End of hive insertion operation #########################################
	def dictionaryPartitionWriteB(self,config = None):
		if len(self.newitemIdDict) is 0:
			return
		with open(self.config.itemidPartitionpath,'w+') as  datawriter:
			ind = 0
			for keys,values in self.itemidDict.iteritems():
				datawriter.write(ind + '\t' + keys + "\t" + values)
				ind += 1
		return
	def delete(self, recievedRdd):
		recieveRdd.registerTempTable('newInserts')	
		dataList = recievedRdd.collect()
		self.newitemdIdDict = {}
		for datum in dataList:
			partItem = 'default_partition'
			if self.setTableName.find('odsposoutletitems') is not -1:
				self.hive_context.sql('delete from ' + self.setTableName + ' where itemid=' + datum.itemid + ' and partitioner =' + datum.partitioner)#+ ' datum.bussinessid_parts = ' + self.getbusinessParts(datum.bussiness_id))
			if self.setTableName.find('odsitems') is not -1:
				self.hive_context.sql('delete from '  + self.setTableName + ' where itemid =' + datum.itemid + ' and partitioner =' + datum.partitioner) #+ ' datum.bussinessid_parts = ' + self.getbusinessParts(datum.business_id) )
		spark.catalog.dropTempView('newInserts')
		return 1
##################################################################################################
	def dictionaryInsert(self,rRdd):
		self.insert(rRdd)
		return
	def dictionaryUpdate(self,rRdd):
		self.delete(rRdd)
		self.insert(rRdd)
		return
		
	def closeEverything(self,):
		
		return
	def remappingDatarecords(self,rdd):
		self.hiveDelete(rdd)
		self.hiveInsert(rdd)

		return
	def loadStacks(self,):
		tempStack = self.loadPickledFile(path_ = self.config.stackPath[0],fileName=self.config.stackName[0])
		if tempStack is not None:
			self.stack1 = tempStack
		tempStack = self.loadPickledFile(path_ = self.config.stackPath[1],fileName=self.config.stackName[1])
		if tempStack is not None:
			self.stack2 = tempStack
		
	def loadPickledFile(self,path_ = '/npd/test/pickledFile/', fileName = 'defaultName'):
		try:
			loadedData = pickle.load(os.path.join(path_,fileName))
		except (OSError, IOError):
			print "File object unavailable"
			return  None
		else:
			if len(loadedData ) is 0:
				return None
			return loadedData
	
		return


    	def createPickledFile(self,path_ = '/npd/test/pickledFile/', fileName = 'defaultName', Ob = None):
 		try:
			pickle.dump(Ob,os.path.join(path_,fileName))
		except (ValueError, IOError,OSError) as e:
			print "something unusual happened: " + str(e)
			return False
		else:
			print "Successfull Dumping"
			return True
			
		return True

################################### End of Pickling ###########################################
    	def inititemidBusiness(self,):
		with open(self.configitemBusiness,"r+") as dataReader:
			try:
				for each in dataReader:
					data = each.split('\t')
					self.itemidBusiness[long(data[0].strip())] = data[1].strip()
			except ValueError as e:
				print(e)
			except IndexError as e:
				print (e)
		return None

