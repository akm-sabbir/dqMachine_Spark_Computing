import sys
import datetime
import os
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark import SparkContext
from pyspark import SparkConf

class hdfsWriteback(writeBackmodule):
	def __init__(self,sc_ = None,nameNodeuri = None):
		self.sc = sc_
		self.namenodeUri = nameNodeuri
		self.URI = None
		self.Path = None
		self.fileStatus = None
		self.Configuration = None
		self.FileSystem = None
		self.conf = Configuration()
		self.fs = None
		self.pathList = None
		self.status = None
		return
	def __str__(self,):
		print "I am hdfs writeback module"
		return
	def listOfpath(self, listofPath = None):
		if listofPath is None:
			print "Nothing to check something is wrong"
			raise ValueError
		return
	def initJavaFrameworks(self,):
		self.URI = self.sc._gateway.jvm.java.net.URI
		self.Path = self.sc._gateway.jvm.org.apache.hadoop.fs.Path
		self.fileStatus = self.sc._gateway.jvm.org.apache.hadoop.fs.FileStatus
		self.FileSystem = self.sc._gateway.jvm.org.apache.hadoop.fs.FileSystem
		self.Configuration = self.sc._gateway.jvm.org.apache.hadoop.conf.Configuration
		return
	def initNamenode(self,):
		self.fs = self.FileSystem.get(self.URI(self.namenodeURI),self.Configuration())
		return
	def initRootdir(self,rootPath = None):
		try:
			self.fs.listStatus(rootPath)
			return True
		except:
			print "Path does not exist"
			print "java file not found Exception"
			return False
		return True
	def load(self,):
		print "Loading authentication for hdfs"
		return
	def insert(self,rdd = None,delimiter='|',header = True,repartition = True,inferSchema = True,codec="bzip2",path = None):
		if rdd is None or path is None:
			print "Noting to write in hdfs"
			return False
		try:
			self.hdfswrite(rdd,delimiter,header,repartition,inferSchema,codec,path)	
		except (ValueError or NameError or TypeError or IOError or OSError) as e:
			print "there is an exception: " + str(e)
			return False
		return True
	def hdfswrite(self,rdd,delimiter,header,repartition,inferSchema,codec,path):
		if repartition is True and codec is not None:
			rdd.repartition(1).write.format("com.databricks.spark.csv").option("inferSchema",inferSchema).option("header",header).option("delimiter",delimiter).option("codec",codec).save(path)
		elif codec is not None:
			rdd.write.format("com.databricks.spark.csv").option("inferSchema",inferSchema).option("header",header).option("delimiter",delimiter).option("codec",codec).save(path)
		else:
			rdd.write.format("com.databricks.spark.csv").option("inferSchema",inferSchema).option("header",header).option("delimiter",delimiter).save(path)

	
		return True
	def update(self,):
		return
	def delete(self,path_ = None):
		try:
			self.fs.delete(Path(path_))
			return True
		except:
			print "Java IO exception could not delete"
			return False
		return True
	def isExist(self, path_ = None):
		if path_ is None:
			return False
		
		if self.status is not None and len(self.status) is not 0:
			for each in self.status:
				if each == path_:			
					return True

		return False
			
