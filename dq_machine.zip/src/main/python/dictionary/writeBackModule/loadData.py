from hdfsFileDiscovery import todaysKey
from hdfsFileDiscovery import rangeOfdate
from processingUnit import startReadingfromhive
from processingUnint import hiveInit
from processingUnit2 import startReadingfromhdfs
from processingUnit import quiet_logs
from hdfsFileDiscovery import globalMain
from processingUnit2 import getColumnsname
from updatePositems import getColumnsnameods
from processingUnit2 import getLastfilenumber
def loadData(data_path,spark = None, readHdfs = 1,odsitem=1, outletitem = 0):
	if len(sys.argv) == 2:
        	print("Usage: snapshotdetector number of days" + str(sys.argv[1]))
        	ranges = int(sys.argv[1])
        quiet_logs(sc_ = spark)
        hc, sqlc = hiveInit(sc_ = spark)
        groupedDict = globalMain(pathName = data_path,sc_= spark)
        print("start reading snapshots")
        date_list = rangeOfdate(ranges) if ranges is not 0 else todaysKey()
        totalsnapShots = sqlc.createDataFrame(spark.emptyRDD(),StructType([]))
        fileList = []
        for each in groupedDict.iteritems():
                if each[0][:-1] not in date_list and  each[0][:-2] not in date_list :
                        continue
                fileList = fileList + each[1]
        if len(fileList )is 0:
                print "Its empty exiting"
                exit(0)
        print ("Get the filtered files to read")
        needToread,last_file_num = getLastfilenumber(fileList)
        print ("start reading snapshot files")
        stringedList = ",".join(needToread)
	query = "select distinct ITEMID, BUSINESSID, SUBCATEGORYN, ITEMNUMBER, UNITSPERPACKAGE, FLD01, FLD02, FLD03, FLD04, FLD05, FLD06, FLD07, FLD08, FLD09, FLD10, FLD11, FLD12, FLD13, FLD14, FLD15, FLD16, FLD17, FLD18, FLD19, FLD20, FLD21, FLD22, FLD23, FLD24,FLD25, FLD26, FLD27, FLD28, FLD29, FLD30, FLD31, FLD32, FLD33, FLD34, FLD35, FLD36, FLD37, FLD38, FLD39, FLD40, FLD41, FLD42, FLD43, FLD44, FLD45, FLD46, FLD47, FLD48, FLD49, FLD50, FLD51, FLD52, FLD53, FLD54, FLD55, FLD56, FLD57, FLD58, FLD59, FLD60, FLD61, FLD62, FLD63, FLD64, FLD65, FLD66, FLD67, FLD68, FLD69, FLD70, FLD71, FLD72, FLD73, FLD74, FLD75, FLD76, FLD77, FLD78, FLD79, FLD80, FLD81, FLD82, FLD83, FLD84, FLD85, FLD86, FLD87, FLD88, FLD89, FLD90, FLD91, FLD92, FLD93, FLD94, FLD95, FLD96, FLD97, FLD98, FLD99, STATUS, ADDED, UPDATED, VFLD01, VFLD02, VFLD03, VFLD04, VFLD05, COUNTRY_CODE, GROUPITEMID, PARENTITEMID, PARENTITEMID_STATUS, OUTLETITEM_MAP_CHANGE_DATE, LOCKDOWN_STATUS from dqdictionaryhivedb.uniqueodsitems_int" if odsitem is 1 else  "select " +",".join(getColumnsname()) + ", partitioner  from dqdictionaryhivedb.uniqueodsposoutlet_int" 
        snapshotRdd = startReadingfromhdfs(sqlc = sqlc, listOffiles = needToread, spark = spark,multi=2)
        query = "select " +",".join(getColumnsname()) + ", partitioner  from dqdictionaryhivedb.uniqueodsposoutlet_int"
        baseDict = startReadingfromhdfs(sqlc = sqlc,listOffiles = '/npd/ODS/ODS_INPUTS_BZ2/ODS_POSOUTLETITEMS',multi = 1, spark = spark) if readHdfs is 1 else startReadingfromhive(query = query, hc = hc, sqlc=sqlc,spark = spark)
        listofC = getColumnsname() if odsitem is 0 else getColumnsnameods()
	cols = columnRenaming(listofC) 
	snapshotRdd = snapshotRdd.selectExpr(cols)
	baseDict = baseDict.selectExpr(cols) if readHdfs is 1 else baseDict
	return snapshotRdd,baseDict
