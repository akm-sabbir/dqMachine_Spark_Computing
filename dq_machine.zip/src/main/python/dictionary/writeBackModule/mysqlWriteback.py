from collections import defaultdict
class mysqlWriteback():
	def __init__(self, config_path = None, mode = None):
		self.authenticationPath = config_path
		self.metaInfo = defaultdict(str)
		self.jdbc_url = None
		self.configData = None
		self.table = None
		self.mode = mode
		self.connectionProps = defaultdict(str)
		return
	def load(self):
		print "Start loading meta information"
		with open(self.authenticationPath,'r+') as dataReader:
			self.configData = dataReader.readlines()
			for each in self.configData:
				name,value = each.split('\t')
				self.metaInfo[name] = value
		print "End of loading meta information"
		return

	def buildUrl(self,):
		if self.jdbc_url is None :
			#self.jdbc_url = "jdbc:mysql://{0}:{1}/{2}?user={3}&password={4}&serverTimezone={5}&zeroDateTimeBehavior={6}".format(self.metaInfo['hostname'],self.metaInfo['portname'],self.metaInfo['dbname'],self.metaInfo['username'],self.metaInfo['password'],self.metaInfo['timeZone'],self.metaInfo['zeroDateTimeBehavior'])
			self.jdbc_url = "jdbc:mysql://" + self.metaInfo['hostname']+ "/" + self.metaInfo['portname'] + "?serverTimezone=UTC"
			return True
		return False
	def setTable(self,table):
		if table is None:
			print "there is something wrong with table name"
			raise ValueError
		self.table = table
		return
	def setMode(self,mode):
		self.mode = mode
		return
	def buildConnectionprops(self,):
		self.connectionProps['usr']=self.metaInfo['username']
		self.connectionProps['password'] = self.metaInfo['password']
		self.connectionProps['driver'] = self.metaInfo['driver']
		return
	def writingBack(self ,rdd):
        	rdd.write.format("jdbc").jdbc(url = self.jdbc_url, table = self.metaInfo['table'], properties = self.connectionProps, mode = self.mode)
		return
	def initiate_ops(self,):
		self.load()
		self.buildUrl()
		self.buildConnectionprops()
		return
	def getJdbcurl():
		return self.jdbc_url
if __name__ == '__main__':	
	ob = mysqlWriteback(config_path='../configuration/mysqlProperties',mode='append')
	ob.initiate_ops()
