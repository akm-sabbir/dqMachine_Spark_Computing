###!/usr/bin/env
from pyspark import SparkConf,SparkContext
#from pyspark.sql import HiveContext
#from pyspark import SQLContext
#from pyspark.sql import Row
#from pyspark.sql.types import *
#from pyspark.sql.functions import avg, udf, col
#from pyspark.sql.types import StringType
#import MySQLdb
#import numpy as np
from collections import defaultdict
from processingUnit import hiveExecutecommands
#from find_candidate_itemids import find_candidate_itemids
'''
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
'''

class hiveContextOpsforpartition(object):
    
    def __init__(self, configFile="../itemidWithPartition.txt", hive_context = None, version = "08", numPart = 200, tempResultdir = 'src/main/python/dictionary/fileSource/tempResultdir'):#itemIdWithPartition.txt"):
        self.configFile = configFile
        self.itemIdDict = defaultdict(str)
	self.hc = hive_context
	self.version = version
	self.partitions = numPart
	self.tempResultdir = tempResultdir
        return
    def testData(self, fileName = "src/main/python/dictionary/itemidMetadata/itemidFreq04.txt", sep = '\t',inds = None):#"itemidOutput.txt", sep = '\t'):
        with open( fileName , "r+" ) as dataSource:
            for ind, each in enumerate(dataSource):
		elemList = each.split(sep)
		if elemList[inds[0]] == 'NULL' or elemList[inds[0]] == None or elemList[inds[0]] == 'None':
			continue
		if elemList[inds[1]] == 'NULL' or elemList[inds[1]] == None:
			continue
		elemList[inds[0]] = long(elemList[inds[0]])
		elemList[inds[1]] = long(elemList[inds[1]])
                yield (ind, elemList)
        return
    def hivePropertySetup(self,):
        self.hive_context.sql('set mapreduce.map.memory.mb=12000')
        self.hive_context.sql('set mapreduce.map.java.opts=-Xmx12000m')   
        self.hive_context.sql('set mapreduce.reduce.memory.mb=9000')
        self.hive_context.sql('set mapreduce.reduce.java.opts=-Xmx7200m')
        self.hive_context.sql('set hive.exec.dynamic.partition.mode=nonstrict')
        self.hive_context.sql('set hive.tez.container.size=10240')
        self.hive_context.sql('set hive.tez.java.opts=-Xmx8192m')
        self.hive_context.sql('set hive.vectorized.execution.enabled = true')
        self.hive_context.sql('set hive.vectorized.execution.reduce.enabled = true')
        return
    def getCountsfromhive(self,file_name = 'src/main/python/dictionary/itemidMetadata/itemidFreq04.txt',query = 'select itemid,count(*) as itemidCount from dqdictionaryhivedb.posoutletitems_ext_bz group by itemid'):
	rddData = hiveExecutecommands(query, hive_context = self.hc)
	results  = rddData.rdd.map(lambda x : (x.itemid, x.itemidCount)).collect()
	with open(file_name, 'w+') as dataWriter:
		for each in results:
			dataWriter.write(str(each[0])  + '\t' + str(each[1]) + '\n')
	return
	
    def generateStat(self,):
        totalList = []
        for each in self.testData(inds = [0,1]):
            totalList.append(each)
        totalList = sorted(totalList, key = lambda x : int(x[1][1]))
        print str(totalList[0]) + " " + str(totalList[len(totalList) - 1])
	print " start of generating statistics "
        with open(self.tempResultdir + "sortedItems.txt", "w+") as dataWriter:
            for each in totalList:
                each_1 = each[0].strip() if(isinstance(each[0],int) == False) else each[0]
                each_2 =  each[1][0].strip() if(isinstance(each[1][0],long) == False) else  each[1][0]
                each_3 = each[1][1].strip() if(isinstance(each[1][1], long) == False) else each[1][1]
                dataWriter.write( str(each_2) + '\t' + str(each_3) + '\n')
        return
    def secondTest(self, ):
        dict_ = defaultdict(list)
        for each in self.testData(fileName = self.tempResultdir + "sortedItems.txt", inds = [0,1]):
            dict_[int(each[1][1])].append(long(each[1][0]))
        result = []
        for key, value in dict_.iteritems():
                result.append((key,len(value)))
        result = sorted(result, key = lambda x : x[1])
        with open(self.tempResultdir + "final_result","w+") as dataWriter:
            for each in result : 
                dataWriter.write(str(each[0]) + " " + str(each[1]) + '\n')
            
        return
    def combinePartitionWithItemid(self):
        dict_ = defaultdict(list)
        for each in self.testData(fileName =  self.tempResultdir + "sortedItems.txt", inds = [0,1]):
            dict_[int(each[1][1])].append(long(each[1][0]))
        dict_2 = defaultdict(str)
        with open(self.tempResultdir + "final_result2", "r+") as data_reader2:
            data = data_reader2.readlines()           
            for datum in data:
                datum_ = datum.split('\t')
                if(dict_2[long(datum_[0].strip())] == ''):
                    dict_2[long(datum_[0].strip())] = datum_[1].strip()
        with open("src/main/python/dictionary/maps/itemIdWithPartition" + self.version + ".txt","w+") as data_writer:
            for key,val in dict_.iteritems():
                for each in val:
                    data_writer.write(str(key) + "\t"+ str(each) + "\t" + str(dict_2[key].strip()) + "\n" )

        return

    def startMergeAndSort(self, numbers):
        if(len(numbers) > self.partitions):
            i = len(numbers) - 1
            j = 0
            results = []
            while(True):
                if(i < j):
                    break
                results.append((numbers[i][0] + numbers[j][0], numbers[i][1] + numbers[j][1]))
                i-=1
                j+=1
            results = sorted(results, key = lambda x : x[1])
            numbers = self.startMergeAndSort(results)
        return numbers

    def getStats(self,):
        numbers = []
        for each in self.testData(fileName = self.tempResultdir + "final_result", sep=' ', inds = [0,1]):
            numbers.append(([each[1][0]],float(each[1][0])*float(each[1][1])))
        numbers = sorted(numbers, key = lambda x : x[1])
        data = self.startMergeAndSort(numbers)
        with open(self.tempResultdir + "final_result2", "w+") as data_writer2:
            for ind,each in enumerate(data):
                for datum in each[0]:
                    data_writer2.write(str(datum) + "\t" + "partition_" + str(ind) + "\t" + str(each[1])+'\n')
            
        #with open("final_result", "w+") as data_writer:
         #   data_writer.write()
        #print str(np.mean(numbers)) + " " + str(np.std(numbers))
        return
######################### beyound is frequency based distribution algorithms ##############################
######################### init functions ####################################################
######################### Start of Pickling ################################################################
    def loadPickledFile(self,path_ = '/npd/test/pickledFile/', fileName = 'defaultName'):
	try:
		loadedData = pickle.load(os.path.join(path_,fileName))
	except (OSError, IOError):
		print "File object unavailable"
		return  self.partitionDict.keys()
	else:
		if len(loadedData ) is 0:
			return self.partitionDict.keys()
		return loadedData
	
	return
    def createPickledFile(self,path_ = '/npd/test/pickledFile/', fileName = 'defaultName', Ob = None):
 	try:
		pickle.dump(Ob,os.path.join(path_,fileName))
	except (ValueError, IOError,OSError) as e:
		print "something unusual happened: " + str(e)
		return 0
	else:
		print "Successfull Dumping"
		return 1
			
	return 1
################################### End of Pickling ###########################################
    def initItemIds(self,):
        try:
            if self.fileHandler is None :
	    	self.fileHandler = open('itemIdWithPartition02.txt','a') 
	    
            with open(self.configFile, "r+") as dataReader:
                for each in dataReader:
                    data = each.split('\t')
                    self.itemIdDict[long(data[1].strip())] = data[2].strip()
		    self.partitionDict[data[2].strip()] = 0
        except FileNotFoundError as e:
            print (e)
            return None
        except IndexError as e:
            print (e)
            return None
################### start writing back to files functions ######################################
################### End of Writing back any files ############################################       
# main sequence of operation 
# initally create the hivecontextObject then call init function, then quiet the log and creat the hive and scala context to call
# appropirate function 
#def execute(listOfItemid == None):
 #   if(listOfItemid == None):
 #       print "need to provide the required itemids"
  #      raise ValueError
  #      return
def generatingUniformDistributionOfData(this):
    this.getCountsfromhive()
    this.generateStat()
    this.secondTest()
    this.getStats()
    this.combinePartitionWithItemid()
    return

if __name__== '__main__':
    	this = hiveContextOpsforpartition()
	generatingUniformDistributionOfData(this)
# End of the File
