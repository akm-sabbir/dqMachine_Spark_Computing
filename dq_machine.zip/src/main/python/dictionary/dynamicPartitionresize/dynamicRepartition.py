import math
import os
import sys
import re
class dynamicRepartition(object):

	def __init__(self,file_name = '/hdpdata/pysparkProject/dqMachine/src/main/python/dictionary/configuration/resource_config', data = [] ,object_name  = 'dynamic_repartitioner',mode = "r+", splitter = '\t'):
		self.file_name = file_name
		self.num_executors = 0
		self.num_cores = 0
		self.driver_mem = 0
		self.executor_mem = 0
		self.commandline_param = 0
		self.pyfiles = None
		self.name = object_name
		self.mode = mode
		self.fileReader = None
		self.data = data
		self.splitter = splitter
		self.data_size = 0	
		self.cluster_size = 10
		self.node_mem = 256
		self.data_unit_size = 2000
		self.min_partition = 10
		self.pattern = "^[+-]?[0-9]+"
		return

	def __str__(self,):
		print "number of executors: " + str(self.num_executors)
		print "number of cores : "  + str(self.num_cores)
		print "number of driver memory: " + self.name
		print "cluster size: " + str(self.cluster_size)
		print "splitting characters: " + str(self.splitter)
		print "node memory: " + str(self.node_mem)
		print "data unit size: " + str(self.data_unit_size)
		print "data size: " + str(self.data_size)
		return "partition class"

	def loadFile(self):
		try:
			with open(self.file_name,self.mode) as fileReader:
				self.data = fileReader.readlines()
		except ValueError, e:
			print "the file might be missing "  + str(e)
		return

	def doParsing(self):
		pat = re.compile(self.pattern)
		try:
			for each in self.data:
				name, value = each.split(self.splitter)
				setattr(self, name, int(value.strip()) if pat.search(value.strip()) is not None else value.strip() )
		except ValueError, e:
			print e
		return

	def set_data_size(self,data_size):
		self.data_size = data_size
		return

	def set_threshold(self, threshold):
		self.threshold = threshold
		return

	def get_gigsize(self,):

		data_size_gb = float(self.get_per_task_data() * self.data_unit_size)/math.pow(10.,9)
		return data_size_gb
	
	def get_total_data_gigsize(self,):

		data_size_gb = float(self.data_size * self.data_unit_size)/math.pow(10.,9)
		return data_size_gb

	def get_parallel_resource_consumption(self,):

		parallel_resource = self.num_executors * self.num_cores
		return parallel_resource

	def get_total_mem_usage_per_node(self):

		total_mem_usage = (self.num_executors/self.cluster_size) * self.executor_mem
		return total_mem_usage

	def  get_per_task_mem(self):

		per_task_mem = self.executor_mem/ self.num_cores
		return per_task_mem
	
	def get_per_task_data(self,):

		resize = self.data_size / self.get_parallel_resource_consumption()
		return resize

	def get_memory_warning(self):

		if get_per_task_mem() < get_per_task_data() :
			return 1
		else:
			return 0
		return 0

	def dynamicPartitionresizer(self):

		per_core_mem = self.executor_mem / self.num_cores
		total_mem_usage = self.get_total_mem_usage_per_node()
		resize = self.get_per_task_data()
		resize_gig = self.get_gigsize()
		memory = self.get_per_task_mem()
		if resize_gig < 0.7*memory :
			resize_gig = 0.7*memory
			num_partition = math.ceil(self.get_total_data_gigsize() / resize_gig)
			print "recalculated  number of partition " + str(num_partition)
			if num_partition < self.min_partition:
				return self.min_partition
			return int(num_partition)
				
		return resize
	@staticmethod
	def factoryFunc(file_name = '/hdpdata/pysparkProject/dqMachine/src/main/python/dictionary/configuration/resource_config', mode = "r+", splitter = '\t'):
		this = dynamicRepartition(file_name = file_name, mode = mode, splitter = splitter)
		this.loadFile()
		this.doParsing()
		print this.dynamicPartitionresizer()
		return this
if __name__ == '__main__':
	this = dynamicRepartition.factoryFunc()
	print this
	
	
