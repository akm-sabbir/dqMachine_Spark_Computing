import setup_db as db

from pyspark import SparkConf
from pyspark import SparkContext
import appDebug
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *

# ##########################
# ##########################
#
# Function to find corresponding ITEMIDs
# using the UPC, SKU+Outlet, Model#-Brand
# Note that this comes from a map which will need to be
# updated periodically
#
# ##########################
# ##########################
def filterFunc(index, dataArr):
	
	return
def find_candidate_itemids(_verbosity = 1, sc = None):

    # #################
    # Load the dictionary db
    mydb = db.dictionary_status_setup(_verbosity)
    
    # modified the code in here to work for testing
    results = mydb.start_upc_search('UPC_SEARCH')

    # Define lists for the output
    upc_results = []
    sku_results = []
    mod_results = []
    #map(filterFunc,range(len(results['ChID']),results['UPC']))
    for i,ch in enumerate(results['ChID']):
        if results['UPC'][i] is not None:
            upc_results.append(results['UPC'][i])
        elif results['SKU'][i] is not None:
            sku_results.append(str(results['POSOUTLET'][i])+'NPD'+str(results['SKU'][i]))
        elif results['MOD'][i] is not None and results['BRAND'][i] is not None:
            mod_results.append(str(results['BRAND'][i])+'NPD'+str(results['MOD'][i]))

    # ##########################
    # ##########################
    # Load the reference datas
    # ##########################
    # ##########################

    #conf = SparkConf()
   #sc = SparkContext(conf=conf)
    sc.setLogLevel("ERROR")

    # ##########################
    # Load the business map into the session
    busMapFile = sc.textFile('/npd/ODS/ODS_INPUTS/ODS_BUSINESSES')
    busMapData = busMapFile.collect()

    bus_map = {}
    for d in busMapData:
        d = str(d.strip())
        if d is not  '':
            d = d.split('|')
            bus_map[int(d[1])] = d[0]


    sqlContext = SQLContext(sc)

    # ##########################
    # UPC SEARCHING
    df_upc = process_searching(sqlContext,'UPC',upc_results) if len(upc_results) is not 0 else []
    upc_list = df_upc.select("ITEMID").rdd.map(lambda x: x.ITEMID).collect() if len(df_upc) is not 0 else []
    if len(upc_list) is 0:
	print("Returned upc list is empty")
	print("UPC  Processing is done here")
    #print(upc_list)
    
    #return(upc_list)
    # ##########################
    # SKU SEARCHING
    df_sku = process_searching(sqlContext,'SKU',sku_results) if len(sku_results) is not 0 else []
    sku_list = df_sku.select("ITEMID").rdd.map(lambda x : x.ITEMID).collect() if len(df_sku) is not 0 else []
    if len(sku_list) is 0:
	print("Returned sku list is empty")
	print("SKU processing is done")
    # ##########################
    # MODEL number SEARCHING
    df_mod = process_search(sqlContext, 'MOD',mod_results) if len(mod_results) is not 0 else []
    mod_list  = df_mod.select("ITEMID").rdd.map(lambda x: x.ITEMID).collect() if len(df_mod) is not 0 else []
    if len(mod_list ) is 0 :
	print("Returned mod list is empty")
	print("MOD processing is done")
    #mod_results.append('CQ BELTS & HOSESNPD22951') 
    return upc_list + sku_list + mod_list 
    
def process_searching(_sqlContext, _type,_results):
    print('Processing '+str(_type)+' Search')
    root_directory = '/npd/maps/dictionary/itemid_maps/'
    print(_results)

    data_key = 'UPC'
    if 'UPC' in _type:
        root_directory = root_directory+'upc/UPC_' 
    elif 'SKU' in _type:
        root_directory = root_directory+'sku/SKU_'
        data_key = 'OUTLET_SKU'
    elif 'MOD' in _type:
        root_directory = root_directory+'model/MOD_'
        data_key = 'BRAND_MODEL'

    df = _sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "false").option("delimiter",'|').load(root_directory+'*')
    cols = []
    cols.append('_c0 as '+data_key)
    cols.append('_c1 as ITEMID')
    cols.append('_c2 as COUNT')
    cols.append('_c3 as TOTAL')
    df = df.selectExpr(cols)
    df = df.withColumn('Business', input_file_name())
    df = df.withColumn('Business', regexp_replace('Business', 'hdfs://NPDHDPSL'+root_directory, ''))
    df = df.withColumn('Business', regexp_replace('Business', '.out', ''))

    df = df.filter(col(data_key).isin(_results) == True)
    df.show()

    return(df)

#find_candidate_itemids()
