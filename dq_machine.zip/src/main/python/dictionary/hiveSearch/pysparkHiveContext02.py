#!/usr/bin/env
import pickle
from pyspark import SparkConf,SparkContext
from pyspark.sql import HiveContext
from pyspark import SQLContext
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import avg, udf, col
import pyspark.sql.functions as psf
from pyspark.sql.types import StringType
import MySQLdb
from processingUnit import hiveExecutecommands
import pyspark.sql.functions as psf
#import numpy as np
from collections import defaultdict
#from find_candidate_itemids import find_candidate_itemids

'''
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
'''

class hiveContextOps():
    
    def __init__(self,configFile = "itemIdWithPartition02.txt",config = None):
        self.configFile = configFile
        self.itemIdDict = defaultdict(str)
	self.itemIdBusiness = defaultdict(int)
	self.config = config
	self.fileHandler = None
	self.tableName = None
	self.sc = None
        return

    def testData(self, fileName = "itemidOutput.txt", sep = '\t'):
        with open( fileName , "r+" ) as dataSource:
            for ind, each in enumerate(dataSource):
                yield (ind, each.split(sep))
        return

    def hivePropertySetup(self,):
        self.hive_context.sql('set mapreduce.map.memory.mb=12000')
        self.hive_context.sql('set mapreduce.map.java.opts=-Xmx12000m')   
        self.hive_context.sql('set mapreduce.reduce.memory.mb=9000')
        self.hive_context.sql('set mapreduce.reduce.java.opts=-Xmx7200m')
        self.hive_context.sql('set hive.exec.dynamic.partition.mode=nonstrict')
        self.hive_context.sql('set hive.tez.container.size=10240')
        self.hive_context.sql('set hive.tez.java.opts=-Xmx8192m')
        self.hive_context.sql('set hive.vectorized.execution.enabled = true')
        self.hive_context.sql('set hive.vectorized.execution.reduce.enabled = true')
        return
######################### beyound is frequency based distribution algorithms ##############################
######################### init functions ##################################################################
    def quiet_logs(self,sc_ = None):
        logger = sc_._jvm.org.apache.log4j
        logger.LogManager.getLogger("org").setLevel(logger.Level.ERROR)
        logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)
        return

    def init(self):
        config = SparkConf().setAppName("defaultName").setMaster("local[8]")
        self.sc = SparkContext(conf = config)
        return self.sc

    def createContext(self, sc_ = None):
	self.sc = sc_
        self.hive_context = HiveContext(sc_)
        self.sqlContext = SQLContext(sc_)
        return

    def selectDatabase(self, dbName):
        self.hive_context.sql("use " + dbName)
        return

    def setConditionCol(self,colName):
        self.colName = colName
        return
    def gettableName(self,):
	return self.tableName
############################################################################################################
######################### Start of Pickling ################################################################
    def loadPickledFile(self,path_ = '/npd/test/pickledFile/', fileName = 'defaultName'):
	try:
		loadedData = pickle.load(os.path.join(path_,fileName))
	except (OSError, IOError):
		print "File object unavailable"
		return  self.partitionDict.keys()
	else:
		if len(loadedData ) is 0:
			return self.partitionDict.keys()
		return loadedData
	
	return


    def createPickledFile(self,path_ = '/npd/test/pickledFile/', fileName = 'defaultName', Ob = None):
 	try:
		pickle.dump(Ob,os.path.join(path_,fileName))
	except (ValueError, IOError,OSError) as e:
		print "something unusual happened: " + str(e)
		return 0
	else:
		print "Successfull Dumping"
		return 1
			
	return 1

################################### End of Pickling ###########################################
    def inititemidBusiness(self,):
	with open(self.configitemBusiness,"r+") as dataReader:
		try:
			for each in dataReader:
				data = each.split('\t')
				self.itemidBusiness[long(data[0].strip())] = data[1].strip()
		except ValueError as e:
			print(e)
		except IndexError as e:
			print (e)
	return None
    def initItemIds(self,itemidRdd):
	pairedIdList = itemidRdd.rdd.map(lambda x : (x.itemid, x.partitioner)).collect()
	self.listOfItemid,self.listOfPartition = zip(*pairedIdList)
	self.listOfItemid = list(self.listOfItemid)
	self.listOfPartition= list(self.listOfPartition)
        return

################### start writing back to files functions #####################################
    def dictionaryPartitionWriteB(self,config = None):
	if len(self.newitemIdDict) is 0:
		return
	with open('itemIdWithPartition02.txt','a') as  datawriter:
		for keys,values in self.newitemIdDict.iteritems():
			datawriter.write(keys + "\t" + values)
		 
################### End of Writing back any files ############################################       
################ Retrieve the Partition for single Itemid ####################################
    def retrievePartition(self,itemId ):
        
        try:
            if(self.itemIdDict[itemId] == ''):
                return 'default_partition'
            else:
                return self.itemIdDict[itemId].strip()
        except KeyError as e:
            print "exception key Error"
            return ("error",e)
##################### End of Partition of Retrieval #########################################
###################### Start of Hive Operation #############################################
    
    def getSearchResult(self,partition = None, listOfItemid = None, listing = 0):
        #if(listOfItemid ==  None):
        #    print "list is null so no new Add"
        #    raise ValueError
        #    return
        partition_ = []
        if(listing is 0):
            for ind, each in enumerate(self.listOfPartition):
		if each is not None:
                	partition_.append( "'" + each.strip() + "'")
            #listOfItemid = [long(each) for each in listOfItemid]
	    self.listOfItemid = [str(each) for each in self.listOfItemid]
            #listOfItemid = str(listOfItemid)
            #listOfItemid[1:len(listOfItemid)-1] 
	    print  "Initiate the sql Query"
            searchString = "select * from " + self.gettableName() + " where array_contains(array(" + ','.join(self.listOfItemid) + "), itemid   )  and array_contains(array(" + ','.join(partition_) + "), partitioner)"
	    print "End of the sql Query"
        else:
            searchString = "select * from " + self.gettableName() + " where  partitioner='" +  partition.strip() + "' and itemid=" + str(listOfItemid) 
        #try:
        result = self.hive_context.sql(searchString)
        #except (MySQLdb.Error, MySQLdb.Warning ) as e :
        #    print("exception MySQlDB: ")
        #    print (e)
        #    return None
        #except TypeError as e:
        #    print ("exception TypeError : ")
        #    print (e)
        #    return None
        #except ValueError as e:
        #    print ('something wrong with columns or conditions')
        #    print (e)
        #    return None
        #finally:
        #    pass
	#if result.rdd.isEmpty() == False:
        #	result = result.rdd.map( lambda x : Row(ITEMID = x.itemid, POIID = x.poi_id,BUSINESSID = x.bussiness_id,OUTLETDESCRIPTION = x.outletdescription)).toDF()
        return result
######################################### End of Hive Search Operation ##########################################

        #self.sqlContext.createDataFrame(result).createOrReplaceTempView(self.setTableName)
        #results = self.sqlContext.sql("select itemid, businessid from " + self.setTableName   )
        #results = results.rdd.map( lambda x : x.itemid + " " + x.businessid).take(50)
       
        #schemaString = "tableName"
        #fields = [StructField(f_name, StringType()) for f_name in schemaString.split()]
        #schema = StructType(fields)
        #schemaTab = sqlContext.createDataFrame(result,schema)
        #schemaTab.show()
        #bank = self.hive_context.table('odsitems')

    def searchTable(self, tableName):
        if(tableName == None):
            print "provide a valid table Name"
	    raise ValueError 
            return
        self.tableName = tableName
        return
############## Database selection Step ########################
    def selectDatabase(self,dbName ):
        if(dbName == None):
            print "provide database name"
	    raise ValueError 
            return
        try:
            self.hive_context.sql("use " + dbName)
        except:
	    print("could not execute use database command")
            return 0
        return 1

    def selectTable(self,tableName):
	if tableName is None:
		print "provide a valid table name"
		raise ValueError
		return
	self.tableName = tableName
	return
############# End of Database selection step #################
############# create a dataframe #############################
    def createDataFrame(listOf):
        return self.sqlContext.createDataFrame(listOf)
############ End of DataFrame Creation ######################

############# Start of Dictionary Search ###################
    def startDictSearch(self, listOfItems = None, listing = 0):

        final_result = self.sqlContext.createDataFrame(self.sc.emptyRDD(),StructType([]))
        #if(listOfItems == None):
	#    raise ValueError
        #    return None
        #if(len(self.itemIdDict) == 0):
        #    self.initItemIds()
    
        if(listing is 1):
            for partition,item in zip(self.listOfPartition,self.listOfItem):
                #partition = self.retrievePartition(each)
                if(partition == None):
                    print("the itemid is missing in dictionary") 
                    continue
                elif (isinstance(partition,tuple()) == True):
                    if(partition[0] == "error"):
                        print(e) 
                else:
	            if fina_result.rdd.isEmpty() is True:
                    	final_result = self.getSearchResult(partition = partition, listOfItemid = item, listing = listing)
		    else:
			final_result.unionAll(self.getSearchResult(partition = partition, listOfItemid = item , listing = listing))

        else:
            listOfPart = []
            #for each in listOfItems:
             #   listOfPart.append(self.retrievePartition(long(each))) 
	    #print listOfPart
            final_result = self.getSearchResult(partition = None, listOfItemid = None,listing = listing)
        return final_result
############################## End of Dictionary Search #######################################
############################# Hive update operation ###########################################
################# dont require to work on it ##################################################
    def startFiltering(self, rdd, threshold = 20000):
	rddTemp = rdd.groupBy("itemid").count().select(psf.col("itemid").alias("itemid_"),psf.col("count").alias("counting"))
	rddTemp = rddTemp.where(rddTemp.counting < threshold)
	rdd = rdd.alias("rdd").join(rddTemp.alias("rddTemp"),psf.col("rdd.itemid") == psf.col("rddTemp.itemid_"),"inner")
	rdd = rdd.drop("itemid_")
	rdd = rdd.drop("counting")
	return rdd  
    def hiveUpdate(self,recievedRdd):
	#self.hive_context.sql('Update ' + self.setTableName + ' set ')
	print ("Look for delete reinsert")
	return

###################### End of hive update operation ###########################################
	
    def getbusinessParts(self,businessId):
	businessId = int(businessId)
	if businessId >= 50 and businessId <= 55:
		return 55
	elif businessId >= 56 and businessId <= 60:
		return 60
	elif businessId >= 61 and businessId <= 65:
		return 65
	elif businessId >= 66 and businessId <= 70:
		return 70
	elif businessId >= 71 and businessId <= 75:
 		return 75
	elif businessId >= 76 and businessId <= 80:
		return 80
	elif businessId >= 81 and businessId <= 85:
		return 85
	elif businessId >= 86 and businessId <= 90:
		return 90
	elif businessId >= 91 and businessId <= 110:
		return 110
	elif businessId >= 111 and businessId <= 130:
		return 130
	elif businessId >= 131 and businessId <= 150:
		return 150
	else:
		return 172
	return -1

###################### hive insert operation #######################################
	
	def hiveInsert(self,recievedRdd):
		recieveRdd.registerTempTable('newInserts')
		partitiondict = loadPickledFile(fileName = 'pickledStack')		
		dataList = recievedRdd.collect()
		self.newitemIdDict = {}
		for each in dataList:
			partItem = 'default_partition'
			if len(partitiondict) is not 0:
				partItem = partitiondict.pop()
			else:
				partitiondict = loadPickledFile()
				partItem = partitiondict.pop()
			if self.setTableName.find( 'odsposoutletitems') is not -1:
				self.hive_context.sql('insert into ' + self.setTableName + ' partition (( partitioner = ' + partItem + ')) values ' + (each.poi_id,each.bussiness_id,each.posoutlet,each.outletdivision,each.outletdepartment,each.outletclass,each.outletbrand, each.outletitemnumber,each.outletdescription, each.outletbrandmatch,each.manufacturedcode,each.sku,each.itemid, each.itemtype,each.price, each.manufacturercodestatus, each.loadid, each.status, each.added, each.updated, each.matched_country_code, each.previous_poiid, each.parent_poiid, each.parent_poiid_status, partItem))
				self.newitemIdDict[long(each.itemid)] = partItem
			elif self.setTableName.find('odsitems') is not -1:
				self.hive_context.sql('insert into ' + self.setTableName + ' partition  ( business_parts = '+ self.getbusinessParts(each.business_id) + ')  values ' + (each.itemid, each.bussiness_id,each.subcategoryn, each.itemnumber, each.unitsperpackage,each.status, each.added, each.updated, each.country_code))
				self.newitemIdDict[long(each.itemid)] = partItem

		self.dictionaryPartitionWriteB()
		#self.createPickledFile(fileName = 'pickledStack',Ob = partitiondict)
		spark.catalog.dropTempView('newInserts')
	
		return 

########################### End of hive insertion operation #########################################

	def hiveDelete(self, recievedRdd):
		recieveRdd.registerTempTable('newInserts')	
		dataList = recievedRdd.collect()
		self.newitemdIdDict = {}
		for datum in dataList:
			partItem = 'default_partition'
			if self.setTableName.find('odsposoutletitems') is not -1:
				self.hive_context.sql('delete from ' + self.setTableName + ' where itemid=' + datum.itemid + ' and partitioner =' + datum.partitioner)#+ ' datum.bussinessid_parts = ' + self.getbusinessParts(datum.bussiness_id))
			if self.setTableName.find('odsitems') is not -1:
				self.hive_context.sql('delete from '  + self.setTableName + ' where itemid =' + datum.itemid + ' and partitioner =' + datum.partitioner) #+ ' datum.bussinessid_parts = ' + self.getbusinessParts(datum.business_id) )
		spark.catalog.dropTempView('newInserts')
		return 1
##################################################################################################
	def dictionaryInsert(self,rRdd):
		self.hiveInsert(rRdd)
		return
	def dictionaryUpdate(self,rRdd):
		self.hiveDelete(rRdd)
		self.hiveInsert(rRdd)
		return
		
	def closeEverything(self):
		
		return
	def remappingDatarecords(self,rdd):
		self.hiveDelete(rdd)
		self.hiveInsert(rdd)
    @staticmethod
    def main(sc = None, config = None, itemidRdd = None, hc = None):
        this = hiveContextOps(config = config)
        sc_ = this.init() if sc is None else sc
        this.createContext(sc_)
	if config is None:
        	this.selectDatabase('dqdictionaryhivedb')
	else: 
		this.selectDatabase(config.hivedbOb.get_dbName(index = 0))
	if config is None:
	        this.searchTable('dqdictionaryhivedb.uniqueodsposoutlet2_int')
	else:
		this.searchTable(config.hivedbOb.get_tabNames(dbName_ = config.hivedbOb.get_dbName(index = 0), index = 2))
        this.quiet_logs(sc_)
        this.hivePropertySetup()
        this.initItemIds(itemidRdd) if itemidRdd is not None else None
        return this, sc_

# main sequence of operation 
# initally create the hivecontextObject then call init function, then quiet the log and creat the hive and scala context to call
# appropirate function 
def generatingUniformDistributionOfData(this):
    this.generateStat()
    this.secondTest()
    this.getStats()
    this.comginePartitionWithItemid()
    return

if __name__== '__main__':
    # main function call to object initiator and executing the search 
    this, sc_  = hiveContextOps.main()
    this.startDictSearch()
    print this
  #  this.startDictSearch(  listOfItems = [1304930,1632560],listing = 0).show()
    #generateingUniformDistributionOfData(this)
    '''
    sc = this.init()
    this.quiet_logs(sc)
    this.createContext(sc)
    this.selectDatabase('karun_test')
    this.searchTable('odsitems')
    this.setConditionCol('businessid')
    this.getSearchResult(listOfItemid = [53,61])
    @'''
