#! /usr/bin/env python
#!-*- python -*-

import os
import sys
import re
#import spark_logging as logging
from collections import defaultdict
class configuration(object):
	class hive(object):
		def __init__(self, dbName_ = None):
			self.dbName = dbName_
			self.tableNameDict = {}
	class mysql(object):
		def __init__(self, dbName_ = None):
			self.dbName = dbName_
			self.tableNameDict = {}
			return
	def __init__(self , conf_ = "src/main/python/dictionary/configuration/config.conf", spark_context = None):
		self.conf = conf_
		#self.logger = logging.getLogger("config_logger")
		self.hivedbOb = None
		self.mysqldbOb = None
		self.input_path = None
		self.output_path = None
		self.itemidSource = None
		self.spark_context = spark_context
		self.lagTime = None
		self.itemidMapping = None
		self.poiidSource = None
		self.numberOfpartition = None
		self.stage = {}
		self.listing = 0
		self.input_path = []
		self.output_path = []
		self.lastFilenumbertracker = []
		self.filtering_threshold = None
		self.read_hive_odspos = 0
		self.read_hive_odsitem = 0
		self.myLogger = None
		self.myLoggerinfo = None
		self.upcM = 0
		self.skuM = 0
		self.gen_map = 0
		self.processing_tab = None
		self.processing_date = None
		self.output_path_newadditem  = None
		self.output_path_newaddpoiid = None
		#self.businessSets = None
		return
	
	def __str__(self):
		print self.mysqldbOb
		print self.hivedbOb
		print self.mysqldbOb.get_dbNames()
		print self.hivedbOb.get_dbNames()
		for each in self.mysqldbOb.get_dbNames():
			print self.mysqldbOb.get_tabNames(each)
		for each in self.hivedbOb.get_dbNames():
			print self.hivedbOb.get_tabNames(each)
		print self.businessSets
		print self.stage
		return "configuration class" 
	
	def init_hive_db(self, name_ = []):
		self.hive_db = name_
		return
	
	def init_mysql_db(self,name = "", value_ = []):
		self.mysql_db = name
		return
	
	def init_hive_table(self,name_ = ""):
		self.hive_tab = name_
		return

	def init_mysql_table(self, name_ = ""):
		self.mysql_tab = name_
		return
	def setPath(self, pathName):
		self.conf = pathName
		return
	def setBusiness(self,businessSets):
		self.businessSets = set(businessSets)
		return
	def set_logger_level(self,logger = None, app_log = None, level = 'info'):
		try:
			if app_log is None:
				raise ValueError
		except ValueError, e:
			print "Could not create the logger"
			return None
		if level is 'info':
			app_log.setLevel(logger.Level.INFO)
		elif level is 'error':
			app_log.setLevel(logger.Level.ERROR)
		else:
			app_log.setLevel(logger.Leve.DEBUG)
		return app_log
	def get_logger(self, logger_name = 'main' ):
		self.app_log = self.spark_context._jvm.org.apache.log4j.LogManager.getLogger(logger_name)
		return self.app_log
	def checkException(self, dbName = None):
		if dbName is None:
			raise ValueError
			return
		for each in self.mydqldbOb.values():
			if each.split('_').count(dbName) is not 0:
				return each
		return
	def load(self,):
		try:
			self.filehandler = open(self.conf,"r+")
			for eachRow in self.filehandler:
				array = eachRow.strip("\n").split("\t")
				value = array[1:]
				name = array[0]
				if name.find("hive")  is not -1:
					if name.find("database_name") is not -1:
						if self.hivedbOb is None:
							self.hivedbOb = databaseOb(type_ = "hivedb")
							for each in value:
								self.hivedbOb.set_dbNames(name_ = each)
					elif name.find("table_name") is not -1:
						dbName = name.split('_')[-1].strip()
						for val in value:
							self.hivedbOb.set_tabNames(dbName,val)
					#self.init_hive_db(name_= array[1:]) if name.find("table") is -1 else self.init_hive_table(name = array[1:])
				elif name.find("mysql") is not -1:
					if name.find("database_name") is not -1:
						if self.mysqldbOb is None:
							self.mysqldbOb = databaseOb(type_ = "mysql")
							for each in value:
								self.mysqldbOb.set_dbNames(name_ = each)
					elif name.find("table_name") is not -1:
						dbName = name.split("_")[-1].strip()
						if dbName.find('frontend') is not -1:
							dbName = name.split('_')[-2] +'_' + dbName
						#print dbName
						#dbName = self.checkException(dbName)
						for val in value:
							self.mysqldbOb.set_tabNames(dbName,val)
					#self.init_mysql_db(name = array[1:]) if name.find("table") is -1 else self.init_mysql_table(name = array[1:])
				elif name.find("businesses") is not -1:
					value[-1] = value[-1].strip()
					for ind, each in enumerate(value):
						value[ind] = int(each)
					self.setBusiness(value)
				elif name.find("read_hive_odsitem") is not -1:
					self.read_hive_odsitem = int(value[0])
				elif name.find("read_hive_odspos") is not -1:
					self.read_hive_odspos = int(value[0])
				elif name.find("processing_tab") is not -1 :
					self.processing_tab = value[0]
				elif name.find("gen_map") is not -1:
					self.gen_map = int(value[0])
				elif name.find("filter_") is not -1:
					self.filter_ = int(value[0])
				elif name.find("delta") is not -1:
					self.delta = int(value[0])
				elif name.find("output_path_history") is not -1:
					self.output_path_history = value[0] 
				elif name.find("output_path_newadditem") is not -1:
					self.output_path_newadditem = value[0].strip()
				elif name.find("output_path_newaddpoiid") is not -1:
					self.output_path_newaddpoiid = value[0].strip()
				elif name.find("output_path_mapping") is not -1:
					self.output_path_mapping = value[0]
				elif name.find("stage") is not -1:
					#print len(value)
					self.stage[value[0]] = int(value[1])
				elif name.find("myLogger_") is not -1:
					self.myLogger = name[:-1]
				elif name.find("partition_size_change_") is not -1:
					self.partition_size_change = int(value[0])
				elif name.find("myLoggerinfo") is not -1:
					self.myLoggerinfo  = name
				elif name.find("upcM") is not -1:
					self.upcM = int(value[0])
				elif name.find("skuM") is not -1:
					self.skuM = int(value[0])
				elif name.find("change_dir") is not -1:
					self.change_dir = value[0]
				elif name.find("processing_tab") is not -1:
					self.processing_tab = value[0]
				elif name.find("Source") is not -1:
					try:
						self.itemidSource = array[1] if name.find("itemid") is not -1 else  self.itemidSource
						self.poiidSource = array[1] if name.find("poiid") is not -1 else self.poiidSource 
					except IndexError as index:
						self.logger.info("Array out  of index error " + str(index))
				elif name.find("batchProcessing") is not -1:
					self.listing = value[0]
				elif name.find("lagTime") is not -1:
					self.lagTime = float(array[1])
				elif name.find("itemidMapping") is not -1:
					self.itemidMapping = str(array[1])
				elif name.find('rootDirmapper') is not -1:
					self.root_mapper = defaultdict(str)
					for each in value:
						self.root_mapper[each.split('/')[-1].split('_')[0]] = each
				elif name.find("last_file_number_tracker") is not -1:
					self.lastFilenumbertracker = value
				elif name.find("numberOfpartition") is not -1:
					self.numberOfpartition = int(value[0].strip())
				elif name.find("filtering_threshold") is not -1:
					self.filtering_threshold = int(value[0].strip())
				elif name.find("input_path") is not -1 :
					try:
						self.input_path = value
					except IndexError as ind:
						self.logger.info(" Array out of index error " + str(ind))
				else:
					self.output_path = value if name.find("output_path") is not -1 else self.output_path
		except (ValueError, KeyError, TypeError) as e :
			print("the configuration file is missing should be taken care of" + str(e))
		finally:
			pass
			#self.filehandler.close()

	@staticmethod
	def configurationFactory(sc_ = None):
		#self.logger.info("configuration object creation")
		this = configuration(spark_context = sc_)
		#this.logger.info("configuration object initiating")
		this.setPath('src/main/python/dictionary/configuration/config.conf')
		this.load()
		#this.logger.info("end of configuration of object creation")
		print this
		return this

class databaseOb(configuration):
	def __init__(self, dbName_  = [], type_ = ""):
		self.dbName = dict()
		self.type_ = type_
	def __str__(self,):
		return self.type_
	def set_dbNames(self, name_ = ""):
		try:
			if name_ is "" or name_ is None:
				raise TypeError
			#for each in name_:
			self.dbName[name_.strip()] = []
			return len(self.dbName) - 1
		except (TypeError, ValueError, KeyError) as k:
			logging.info("database name can not be empty " + str(k))
			sys.exit()
	def set_tabNames(self,db_N, tab_N):
		try:
		
			if db_N is "" or db_N is None:
				raise ValueError
			if self.dbName.get(db_N) is not None:	
				
				self.dbName[db_N].append(tab_N.strip())
		except (TypeError, ValueError, KeyError) as v:
			#logging.info("table name or database name can not be empty " + str(v))
			print str(v)
			sys.exit()
	def get_tabNames(self, dbName_ = "", index = -1):
		try:
			if dbName_ is "":
				raise TypeError
			#if inde is -1:
			#	raise IndexError
			#print dbName_
			#print index
			return self.dbName[dbName_] if index is -1 else self.dbName[dbName_][index]
		except TypeError as t:
			#logging.info("database Name can not be empty " + str(t))
			print str(t)
		except IndexError as i:
			#logging.info("indexing error" + str(i))	
			print str(t)
		except KeyError as k:
			print str(k)

	def get_dbNames(self, index = 0):
		db_list = self.dbName.keys()
		return db_list
	def get_dbName(self, index = 0):
		db_list = self.dbName.keys()
		return db_list[index]
	
if __name__ == '__main__':
	this = configuration.configurationFactory()	
	this.get_logger(logger_name = 'main')
	print this
#	print this.input_path
#	print this.output_path
	#print this:wq

