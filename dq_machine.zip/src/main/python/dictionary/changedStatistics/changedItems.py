from pyspark.sql.functions import lit
from pyspark.sql.functions import col
from pyspark.sql.types import DoubleType
from pyspark.sql import Row
from pyspark.sql.functions import avg, udf, col
from operator import add
import pyspark.sql.functions as psf
import MySQLdb
from itertools import islice
from itertools import count
from itertools import izip
from collections import defaultdict
#should have been a class and create a reusable object#
#######################################################
def getChangedItemsforpoiid(baseRdd, snapShotrdd):
	print "Start detecting statistics for poiid"
	snapShotrdd = snapShotrdd.withColumn("poi_id",snapShotrdd["poi_id"].cast("long"))
	baseRdd = baseRdd.withColumn("poi_id",baseRdd["poi_id"].cast("long"))
	conditionTomet = [psf.col("finalrddtemp.poi_id") == psf.col("basetemp.poi_id") ,psf.col("basetemp.itemid") == psf.col("finalrddtemp.itemid")]
	snapShotrddtemp = snapShotrdd.alias("finalrddtemp").join(baseRdd.alias("basetemp"),(psf.col("finalrddtemp.poi_id") == psf.col("basetemp.poi_id")),"inner")	  
	tempRdd = snapShotrddtemp.alias("tempRdd")
	snapShotrddtempmatched = snapShotrdd.alias("finalrddtemp").join(tempRdd,psf.col("finalrddtemp.itemid") == psf.col("tempRdd.itemid"),"inner")
	tempRdd = tempRdd.alias("tempRdd").join(snapShotrddtempmatched,(psf.col("tempRdd.itemid") == psf.col("snapShotrddtempmatched.itemid")),"leftanti")
	print "End of statistics generation for itemid"
	return tempRdd
###################################################
#changeItemsforitemid baseRdd and snapShotrdd
def getChangedItemsforitemid(baseRdd,snapShotrdd):
	print "start detecting statistics for itemid"
	snapShoprdd.withColumn("subcategoryn",snapShotrdd["subcategoryn"].cast("long"))
	conditionTomet = [psf.col("finalrddtemp.subcategoryn") == psf.col("tempRdd.subcategoryn") ,psf.col("tempRdd.itemnumber") == psf.col("finalrddtemp.itemnumber")]
	snapShotrddhis = snapShotrdd.alias("finalrddtemp").join(baseRdd.alias("basetemp"),(psf.col("finalrddtemp.itemid") == psf.col("basetemp.itemid")),"inner")	  
	tempRdd = snapShotrddhis.alias("tempRdd")
	snapShotrdd1 = snapShotrdd.alias("finalrddtemp").join(tempRdd,(psf.col("finalrddtemp.subcategoryn") == psf.col("tempRdd.subcategoryn")),"leftanti")
	snapShotrdd2 = snapShotrdd.alias("finalrddtemp").join(tempRdd,(psf.col("tempRdd.itemnumber") == psf.col("finalrddtemp.itemnumber")),"leftanti")
        snapShotrdd = snapShotrdd1.union(snapShotrdd2)

	print "End of statistics generation for itemid"
	return snapShotrdd
#End of the changed statistics#
