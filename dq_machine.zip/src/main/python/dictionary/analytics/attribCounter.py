#!/usr/bin/env
from pyspark import SparkConf
from pyspark import SparkContext

#from pysparkHiveContext import hiveContextOps
import time
import inspect
#import spark_logging as logging
import sys
import csv
import os
from collections import defaultdict
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark.sql import HiveContext
from pyspark.sql import Row
from pyspark.sql import SparkSession
def toCsvLine(data):
        return '|'.join(str(datum) for datum in data)

def readDataFromCsvFile(filename = None,sqlContext = None):
    #global globalVar.spark_context

    try:
        rdd1 = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "true").option("delimiter","|").option("quote","\\").option("codec","bzip2").option("treatEmptyValuesAsNulls","true").load(filename).repartition(50)
        return rdd1
    except Py4JJavaError as e :
        print("invalid path name for data source")
        return None
    except (OSError,IOError, ValueError) as e :
        print e
        print('No file found '+str(ifile))
        return None
    except pyspark.sql.utils.AnalysisException as e:
        print e
        return None
    return  None

def mainOps(sc_ = None,hive_context = None):
	#hiveContext, sc = hiveContextOps.mainCount(sc = sc_)
	attrib = "fld"
	listofAttrib = [attrib + str(i)+ str(j) for i in xrange(0,10) for j in xrange(0,10) ]
	sqlStatement = "select businessid, subcategoryn, count(subcategoryn),  "
	for ind,each in enumerate(listofAttrib):
		sqlStatement += "sum( ceil(" + each + "/ (" + each + " + 0.0001)) ) as " + each + " , " if ind != len(listofAttrib) - 1 else "sum( ceil (" + each + "/ (" + each + " + 0.0001))) as  " + each  + " "
	sqlStatement += "from odsattributes group by subcategoryn, businessid"
	print sqlStatement
	print "start of hive ops" 
	odsattrib = hive_context.table("dqdictionaryhivedb.odsattrib")
	odsattrib.registerTempTable("odsattributes")
	result = hive_context.sql(sqlStatement)
	results = result.rdd.collect()
	print "Size of the retrieved data: " + str(result.count())
	#result = result.rdd.map(lambda x : toCsvLine(x)).toDF()
	print "End of hive ops"	
	print "End of Csv formatting"
	print "Start writing it back to the hdfs text file"
	with open("/home/abdul.sabbir/attriboutput.txt") as datawriter:
		for each in results:
			datawriter.write(each.strip())
	#result.saveAsTextFile("hdfs://lpwhdqnnp01:50070/npd/test/ODS/TEMPOUTPUT1/attributeCount.csv")
 	#result.repartition(1).write.format("com.databricks.spark.csv").option("inferschema","true").option("header","true").option("delimited","|").save("/npd/s_test2/attribData.csv")
	print "End of the writing back the result"
	return
def generateStatistics(path_ = None,filename= None, sc = None):
	rDD = None
	if path_ is not None:
		path_ = os.path.join(path_, "part-00000-b7f9ac6a-8bd7-4442-8457-07b7c5eeeb71-c000.csv.deflate" )#'part-00000-b3a13288-e5b0-4060-8b79-952635ed159b.csv')
	else:
		rDD = readDataFromCsvFile(filename = filename ,sqlContext = sc )
	reader = rDD.collect()
	#with open(path_, 'rb') as filehandler:
		#reader = csv.reader(filehandler)
		#headers = reader.next()
	results = []
	dictResult = {}
	
	for row in reader:
		dictResult[int(row[0])] = defaultdict(list)
		for ind, val in enumerate(row):
			if ind < 3:
				continue
				#print row_[ind]  + " " + row[2]
			rtemp = float(row[ind])/float(row[2])*100.0
			dictResult[int(row[0])][int(row[1])].append(rtemp)
			#results.append(row[0:10] )
		#for row in results:
		#	print row
	return	dictResult
def detectPercentage(dataFrame, dictResult, sqlContext):
	attribInfo = Row('itemid', 'filledUp','sigAttrib','sigMissing','missing')
	def funcTest(x,dictResult):
		rList = []
		filledout = 0
		counter = 0
		elems = None
		if len(dictResult[int(x[1])][int(x[2])]) is not 0:
			elems = dictResult[int(x[1])][int(x[2])]
			rList.append((x[0],0))
		realMissing = 0
		for ind,datum in enumerate(x[5 : 104]):
			if datum is 0 and elems is not None:
				if elems[ind] > 0.6:
					#rList.append(('fld' + str(ind),each) )
					counter += 1
				else:
					realMissing += 1
			elif datum is not 0:
				filledout += 1
			else:
				realMissing += 1
				
				#	if counter is 10:
				#		break 
				#if counter < 10:
					#while(counter <= 10):
						#rList.append('fld',0)
						#counter += 1
		
		return (x[0],filledout,filledout + counter, counter,realMissing)
	dataFrame = dataFrame.rdd.map(lambda x : attribInfo(*funcTest(x,dictResult))).toDF()
	print dataFrame.first()
	dataFrame = dataFrame.filter(dataFrame.sigMissing != 0 )
	dataFrame = dataFrame.rdd.map(lambda x : Row(ITEM_ID = x.itemid,RANK_1 = "totalFilledup",RANK_2 = "totalSignificantattrib" ,RANK_3 = "significantMissing", RANK_4 = "missingAttrib",RANK_1V = x.filledUp,RANK_2V=x.sigAttrib,RANK_3V=x.sigMissing,RANK_4V = x.missing)).toDF()
	#dataFrame.write.format('jdbc').options(url='jdbc:mysql://lslhdpcd1:3306/dictionary_frontend?serverTimezone=UTC',dbtable='REFS',driver='com.mysql.jdbc.Driver         ',user='root',password='My$qlD').mode('append').save()
	dbproperties = {'user':'root','password':'My$qlD','driver':'com.mysql.jdbc.Driver'}
	dataFrame.write.jdbc(url='jdbc:mysql://lslhdpcd1:3306/dictionary_frontend?serverTimezone=UTC',table='REFS',properties=dbproperties,mode='append')	
	return dataFrame

def quiet_logs(sc_ = None):
	logger = sc_._jvm.org.apache.log4j
	logger.LogManager.getLogger("org").setLevel(logger.Level.ERROR)
	logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)
	return

def hivePropertySetup():
        self.hive_context.sql('set mapreduce.map.memory.mb=6000')
        self.hive_context.sql('set mapreduce.map.java.opts=-Xmx9000m')   
        self.hive_context.sql('set mapreduce.reduce.memory.mb=9000')
        self.hive.context.sql('set mapreduce.reduce.java.opts=-Xmx7200m')
        self.hive_context.sql('set hive.exec.dynamic.partition.mode=nonstrict')
        self.hive_context.sql('set hive.tez.container.size=10240')
        self.hive.context.sql('set hive.tez.java.opts=-Xmx8192m')
        return

def createContext(sc_ = None):
        hive_context = HiveContext(sc_)
        #self.sqlContext = SQLContext(sc_)
        return hive_context


def init():
	spark = SparkSession.builder.appName('attribCounter').config("spark.dynamicAllocation.enabled",True).getOrCreate()
 	conf = SparkConf().setAppName("attribCounter")
    	conf.set("spark.dynamicAllocation.enabled",True)
    	conf.set("spark.yarn.executr.memoryOverhead",8192)
    	conf.set("spark.shuffle.service.enabled",True)
   	conf.set("yarn.nodemanager.vmem-check-enabled",False)
    	conf.set("spark.local.dir","/hdpdata/tmp")
    	conf.set("yarn.nodemanager.vmem-pmem-ratio",6)
    	conf.set("spark.eventLog.enabled",True)
    	conf.set("spark.driver.memory",128)
    	conf.set("spark.eventLog.dir","/hdpdata/logs")
	conf.set("PYSPARK_DRIVER_PYTHON",False)
	conf.set("yarn.log-aggregation-enable",True)
    	#sc = SparkContext(conf = conf)
    	sc.setLogLevel("ERROR")
	hive_context = HiveContext(sc)
    	sqlContext = SQLContext(sc)
	#conf = SparkConf()
	#conf.set('PYSPARK_DRIVER_PYTHON',False)
        #spark_context = SparkContext(conf = conf)
        #spark_context.setLogLevel("ERROR")
        #sqlContext = SQLContext(spark_context)	
	return sc,sqlContext,hive_context
## end of pyspark initiation
def attribCounter(sqlContext = None):
	#sqlContext = init()
	#mainOps()
	source = 'ODS_POSITEMS'
	filepath = None
	with open(source,'r') as datareader:
		filepath = datareader.readlines()
	for ind, each in enumerate(filepath):
		each = each.strip()
		each =  each.split('/')[3:]
		print each
		filepath[ind] = "/".join(each)
		filepath[ind] = "/" + filepath[ind]
	dictResult = generateStatistics(filename = '/npd/test/s_test1/attribCounterAll',sc = sqlContext)
	#dictResult = generateStatistics(path_='./outputsect01/attribData.csv/')
	#for each in dictResult.iteritems():
		#print each
	finaldframe = None
	for each in filepath:
		dframe = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "true").option("delimiter","|").option("quote","\\").option("codec","bzip2").load(each).repartition(40)
		print dframe.count()
		if finaldframe is None:
			finaldframe = dframe
		else:
			finaldframe = finaldframe.unionAll(dframe)
	print "Total Data Size is: " + str(finaldframe.count())
	header = dframe.first()
	#print header
	resultF = detectPercentage(finaldframe, dictResult,sqlContext)
	results = resultF.collect()
	print "End of Sql writeback"
	return

sc_,sqlContext,hiveContext = init()
#sqlContext = SQLContext(sc_)
#hiveContext = createContext(sqlContext)
#mainOps(sc_= sqlContext,hive_context= hiveContext)
attribCounter(sqlContext = sqlContext) 
#dictResult = generateStatistics(filename = '/npd/test/s_test1/attribCounterAll',sc = sqlContext)
