#from hdfs 
import sys
import datetime
import os
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark import SparkContext
from pyspark import SparkConf
import datetime
from collections import defaultdict
from operator import itemgetter,attrgetter
def initSystem(sc = None):
	#conf = SparkConf()
	#sc = SparkContext(conf = conf)
	URI = sc._gateway.jvm.java.net.URI
	Path = sc._gateway.jvm.org.apache.hadoop.fs.Path
	fileStatus = sc._gateway.jvm.org.apache.hadoop.fs.FileStatus
	FileSystem = sc._gateway.jvm.org.apache.hadoop.fs.FileSystem
	Configuration = sc._gateway.jvm.org.apache.hadoop.conf.Configuration
	conf = Configuration()
	distributedSys = sc._gateway.jvm.org.apache.hadoop.hdfs.DistributedFileSystem
	localfileSys = sc._gateway.jvm.org.apache.hadoop.fs.LocalFileSystem
	conf.set("fs.defaultFS","hdfs://lpwhdqnnp01.npd.com")
	#conf.set("fs.hdfs.impl",distributedSys())
	#conf.set("fs.file.impl",localfileSys())
	#val output = fs.create(new Path("/npd/test/ODS/fileName"))
	fs = FileSystem.get(URI("hdfs://lpwhdqnnp01.npd.com"), Configuration())
	#path = Path("/npd/ODS/ODS_INPUTS_BZ2/ODS_POSOUTLETITEMS/")

	return fs,Path
def rangeOfdate(numdays):
	base = datetime.datetime.today()
	date_list = [base - datetime.timedelta(days = x) for x in xrange(0, numdays)]
	date_list = [str(each.year)+str(each.month)+ str(each.day) for each in date_list]
	return date_list, base.hour
def todaysKey(hr = 0,delta = 0):
	dt = datetime.datetime.today() - datetime.timedelta(days = delta)
	return [str(dt.year) + str(dt.month) + str(dt.day)], dt.hour

def getFilelist(dirList, sc_ = None,produce_list = 1):
	fs, Path = initSystem(sc_)
	filelistResult = []
	if produce_list is 1:
		for each in dirList:
			try:
				templist = fs.listStatus(Path(each))
			except:
				print "Skip the exception"
				continue
			filelistResult += templist
	#print "length of the filelist: " +str(len(filelistResult))
		print "restructuring the files"
		for ind, each in enumerate(filelistResult):
			filelistResult[ind] = str(each.getPath())
		with open('src/main/python/dictionary/fileSource/partitioner_list2.txt','w+') as datawriter:
			for each in filelistResult:
				datawriter.write( each+ '\n')
		print "End of file processing."
	else:
		with open('src/main/python/dictionary/fileSource/partitioner_list.txt','r+') as datareader:
			filelist = datareader.readlines()
			for ind,each in enumerate(filelist):
				filelist[ind] = each.strip()
		return filelist
	print "End of the function"
	return  filelistResult
def testgetFile(spark):
	blist = [53 ,55,56,57,58,59 ,61,66,70,76,77,78 ,138,152,160,161,162,174,179]
	pathsub = '/apps/hive/warehouse/dqdictionaryhivedb.db/uniqueodsposoutlet2_int/business_id='
	paths = []
	for each in blist:
		paths.append(pathsub + str(each))
	print paths
	getFilelist(paths,sc_=spark)
	return paths
def globalMain(pathName = '/npd/ODS/ODS_INPUTS_BZ2/ODS_POSOUTLETITEMS/',sc_ = None, debug = 0):
	fs,Path = initSystem(sc_)  #FileSystem.get(URI("hdfs://lpwhdqnnp01.npd.com"), Configuration())
	path = Path(pathName)
	groupedDict = defaultdict(list)
	try:
		status = fs.listStatus(path)
		if debug is 1:
			print len(status)
		fileLists = []
		if len(status) is not 0:
			for ind in xrange(0,len(status)):
				#print str(status[ind].getPath()) + " " + datetime.datetime.fromtimestamp(long(str(status[ind].getModificationTime()))/1000.).strftime('%m-%d-%Y %H:%M:%S')
				fileLists.append((str(status[ind].getPath()),datetime.datetime.fromtimestamp(long(str(status[ind].getModificationTime()))/1000.)))
		fileLists = sorted(fileLists, key = itemgetter(0),reverse = True)
		print fileLists[0][1].strftime('%m-%d-%Y %H:%M:%S')	
		for each in fileLists:
			#print str(each[1].year)+str(each[1].month)+str(each[1].day)+str(each[1].hour)
			groupedDict[str(each[1].year) + str(each[1].month) + str(each[1].day) + " " + str(each[1].hour)].append(each[0])
		if debug is 1:
			for key,values in groupedDict.iteritems():
				print str(key) + ' ' + str(values)
		#print "Path deleting in process ..."
		#fs.delete(Path('/npd/test/s_test/hiveUdf'))
	except ( IOError or ValueError or OSError or TypeError) as e:
		print e
		print "generic exception"
	return groupedDict
#print ("End of the programe execution")
def deletePath(pathName = None,sc_ = None):
	if pathName is not None:
		fs,Path = initSystem(sc_)
		try:
			fs.delete(Path(pathName))
			return True
		except:
			print ("Java IO exception could not delete")
			return False
	return False
#globalMain()
