import logging
from logging.handlers import SysLogHandler
import time
import sys
#from hdfsFileDiscovery import deletePath
#from hdfsFileDiscovery import getLastfilenumber 
from service import find_syslog, Service
from hdfs3 import HDFileSystem
import subprocess

class MyService(Service):
    def __init__(self, *args, **kwargs):
        super(MyService, self).__init__(*args, **kwargs)
        self.logger.addHandler(SysLogHandler(address=find_syslog(),
                               facility=SysLogHandler.LOG_DAEMON))
        self.logger.setLevel(logging.INFO)

    def run_cmd(self, args_list): 
	print('Running system command: {0}'.format(' '.join(args_list))) 
	proc = subprocess.Popen(args_list, stdout = subprocess.PIPE, stderr = subprocess.PIPE) 
	s_output, s_err = proc.communicate() 
	s_return = proc.returncode 
	return s_return, s_output, s_err
    def checkForfiles(self,):
	try:
		print "starting the application service"
		self.run_cmd(['spark-shell', '-i', "/hdpdata/pysparkProject/dqMachine/src/main/python/dictionary/service/applicationService.scala"])
		print "end of the application service"
	except:
		print "ignoring the exception"
		pass
		#s_r,s_o,s_e = run_cmd(['hdfs', 'dfs', '-copyFromLocal', 'src/main/python/dictionary/maps/itemIdWithPartition06.txt', "hdfs:////npd/s_test2/itemidMapper/"])
        #print str(s_r) +str(' and ')+ str(s_o) +' and '+ str(s_e)
	return

    def getLastfilenumber(self,filenames = None,ft = 0 , rw = 0, file_num_ = None):
	last_file_number  = None
	root_part = '/hdpdata/pysparkProject/dqMachine/'
	parentPath = root_part + 'src/main/python/dictionary/configuration/lastfilenumber' if ft is 1 else root_part + 'src/main/python/dictionary/configuration/lastfilenumberOds'
	needToread = []
	if rw is 0:
		with open( parentPath ) as filereader:
	        	last_file_number = filereader.readline()
	   	filenames = sorted(filenames,reverse =True)
	   #needToread = []
          	print( filenames)
	   	for each in filenames:
	      		if (each.split('/')[-1] > last_file_number):
	         		needToread.append(each)
	   	new_file_number = filenames[-1].split("/")[-1]
	   	if new_file_number > last_file_number:
			return 1
	   	else:
			return 0
        else:
	   	with open( parentPath ,'w+') as datawriter:
              		if file_num_ is not None:
		 		print "last file name: " + file_num_
	        datawriter.write(str(file_num_))
	   	return None, None
		
	return file_number

    def run(self):
	fileTypes = [0 , 1]
	root_part = '/hdpdata/pysparkProject/dqMachine/'
        common_part = 'src/main/python/dictionary/fileSource/'
	file_paths = [ root_part + common_part + 'ODS_POSITEMS', root_part + common_part + 'ODS_POSOUTLETITEMS']
	#hdfs = HDFileSystem(host=,port=)
	data_writer = open(root_part + 'src/main/python/dictionary/service/test_output','a+')
        while not self.got_sigterm():
	    apps_tracking  = [ root_part + common_part + 'tracker']
	    self.checkForfiles()
	    time.sleep(10)
	    
	    #try:
	    for i in xrange(0,1):
 		response_list = [0,0]
		for ind,each in enumerate(file_paths):
			with open(each, 'r+') as datareader:
				files = datareader.readlines()
				response_list[ind] = self.getLastfilenumber(files,ft = ind, rw = 0 )
		datum = None
		data_writer.write("we need to initiate the programe")
		try:
				#self.run_cmd(['spark-shell', '-i', "/hdpdata/pysparkProject/dqMachine/src/main/python/dictionary/service/applicationService.scala"])
			data_writer.write( "I am going to sleep now")
			time.sleep(10)
		except:
			data_writer.write( "ignoring the exception")
			pass

	data_writer.close()
	    #except:
	#	print "File not found but we will continue to look for files"
	#	continue
	return

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        sys.exit('Syntax: %s COMMAND' % sys.argv[0])

    cmd = sys.argv[1].lower()
    service = MyService('my_service', pid_dir='/tmp')
	
    if cmd == 'start':
	print "service is going to start"
        service.start()
    elif cmd == 'stop':
	print "we are trying to stop the service"
        service.stop()
    elif cmd == 'status':
        if service.is_running():
            print "Service is running."
        else:
            print "Service is not running."
    else:
        sys.exit('Unknown command "%s".' % cmd)
