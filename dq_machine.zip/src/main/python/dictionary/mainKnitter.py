#!/usr/bin/env python
#!-*- coding:utf-8 -*-
from pysparkHiveContext02 import hiveContextOps
from upcModule.find_candidate_itemids import find_candidate_itemids 
from findNewAdd import find_new_itemid
from findNewAdd.find_new_itemid import getNewaddsv2
from findNewAdd.find_new_itemid import getNewadds
from findNewAdd.find_new_itemid import testMain
import time
import inspect
import spark_logging as logging
import sys
import os
from processingUnit2 import updateOdsposoutlet
from updatePositems import updateOdsitem
#from configuration import configurationFactory
from configuration import configuration
from pyspark import SparkConf
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import SparkSession
#from map_generator import testing_main
from readAndload import loadingData
from hdfsFileDiscovery import  testgetFile
import pyspark.sql.functions as psf
from pyspark.sql.functions import col
from hivewritebackModule import hivewriteback
from processingUnit import hiveInit
from pyspark.sql.types import *
from pyspark.sql.types import StringType
from pyspark.sql.types import DoubleType
from dictionaryPartitioncreator import hiveContextOpsforpartition
from dictionaryPartitioncreator import generatingUniformDistributionOfData
from updatePositems import readsnapshotBasetoupdate
from processingUnit2 import  updatePosoutletwithsnapshots
from map_generator import generateMaps
#import pyspark.broadcast
class globalVariables(object):
	def __init__(self):
		self.debug = False
		self.spark_context = None
		self.dict_status = None

def initSparkContext(globalVar):
    #global globalVar.spark_context
    spark = SparkSession.builder.appName("dqMachineApplication")\
    .config("spark.dynamicAllocation.enabled",False)\
    .config("spark.yarn.executor.memoryOverhead",8096)\
    .config("spark.shuffle.service.enabled",True)\
    .config("yarn.nodemanager.vmem-check-enabled",False)\
    .config("yarn.nodemanager.pmem-check-enabled",False)\
    .config("spark.driver.maxResultSize", "16g")\
    .config("spark.sql.broadcastTimeout", 36000)\
    .config("spark.local.dir","/hdpdata/tmp")\
    .config("yarn.nodemanager.vmem-pmem-ratio",6)\
    .config("spark.eventLog.enabled",True)\
    .config("spark.driver.memory","30g")\
    .config("spark.eventLog.dir","/hdpdata/logs")\
    .config("spark.serializer","org.apache.spark.serializer.KryoSerializer")\
    .config("spark.dynamicAllocation.schedulerBacklogTimeout",10)\
    .config("spark.dynamicAllocation.sustainedSchedulerBacklogTimeout",10)\
    .config("spark.dynamicAllocation.initialExecutors",30)\
    .config("spark.dynamicAllocation.minExecutors",20)\
    .config("spark.dynamicAllocation.maxExecutors",9999999)\
    .config("spark.dynamicAllocation.cachedExecutorIdleTimeout",9999999)\
    .config("spark.dynamicAllocation.executorIdleTimeout",60)\
    .config("spark.default.parallelism",8)\
    .config("spark.scheduler.mode","FAIR")\
    .config("spark.kyroserializer.buffer.mb","1024")\
    .config("spark.kyroserializer.buffer.max.mb","4096")\
    .config("spark.io.compression.codec", "snappy")\
    .config("spark.shuffle.compress", "true")\
    .config("spark.shuffle.service.enabled", "true")\
    .config("spark.memory.fraction", 0.8)\
    .config("spark.memory.storageFraction", 0.35)\
    .config("spark.rpc.askTimeout",1000)\
    .enableHiveSupport().getOrCreate()
    #sc = spark.sparkContext
    #sqlContext = SQLContext(sc)
    #spark.conf = SparkConf().setAppName("dqMachineApplication")
    '''
    spark.conf.set("spark.dynamicAllocation.enabled",True)
    spark.conf.set("spark.yarn.executor.memoryOverhead",16256)
    spark.conf.set("spark.shuffle.service.enabled",True)
    spark.conf.set("yarn.nodemanager.vmem-check-enabled",False)
    spark.conf.set("spark.local.dir","/hdpdata/tmp")
    spark.conf.set("yarn.nodemanager.vmem-pmem-ratio",6)
    spark.conf.set("spark.eventLog.enabled",True)
    spark.conf.set("spark.driver.memory",128)
    spark.conf.set("spark.eventLog.dir","/hdpdata/logs")
    spark.conf.set("spark.serializer","org.apache.spark.serializer.KryoSerializer")
    '''
    globalVar.spark_context = spark.sparkContext #SparkContext(conf = conf)
    globalVar.spark_context.setLogLevel("ERROR")
    sqlContext = SQLContext(globalVar.spark_context)
    return sqlContext
def itemidTopartitionpair(baseRddoutlet, dataFrameItemId, itemidRdd = None, debug = False):
	baseRddoutlet = baseRddoutlet.withColumn("itemid", baseRddoutlet["itemid"].cast("long"))
	dataFrameItemId = dataFrameItemId.withColumn("itemid", dataFrameItemId["itemid"].cast("long"))
	itemidRdd = itemidRdd.withColumn("vitemid",itemidRdd["vitemid"].cast("long")) if itemidRdd is not None else None
	resultantRdd = baseRddoutlet.alias("baseRdd").join(dataFrameItemId.alias("dataFrame"), psf.col("baseRdd.itemid") == psf.col("dataFrame.itemid"),"inner").select(col("baseRdd.itemid").alias("itemid"), "partitioner").distinct() if itemidRdd is None else itemidRdd.alias("itemidRdd").join(dataFrameItemId.alias("dataFrame"), (psf.col("itemidRdd.vitemid") == psf.col("dataFrame.itemid")),"inner").select("itemid", "partitioner")
	if debug is True:
		print "count of total matched data: " + str(resultantRdd.count())
	return resultantRdd

def addAllpath():
	change_path = 'src/main/python/dictionary/'
	change_path2 = './'
	sys.path.append((change_path2 + 'fileSystem/'))
	sys.path.append(os.path.abspath(change_path2  + 'configuration/'))
	sys.path.append(os.path.abspath(change_path2 +  'configurationMod/'))
	sys.path.append(os.path.abspath(change_path2 + 'createScript/'))
	sys.path.append(os.path.abspath(change_path2 + 'debugModule/'))
	sys.path.append(os.path.abspath(change_path2 + 'duplicateDetector/'))
	sys.path.append(os.path.abspath(change_path2 + 'hiveSearch/'))
	sys.path.append(os.path.abspath(change_path2 + 'mapGeneration/'))
	sys.path.append(os.path.abspath(change_path2 + 'upcModule/'))
	sys.path.append(os.path.abspath(change_path2 + 'partitionCreator/'))
	sys.path.append(os.path.abspath(change_path2 + 'itemidMetadata/'))
	sys.path.append(os.path.abspath(change_path2 + 'fileSource/'))
	sys.path.append(os.path.abspath(change_path2 + 'changedStatistics/'))
	sys.path.append(os.path.abspath(change_path + 'fileSystem/'))
	sys.path.append(os.path.abspath(change_path + 'changedStatistics/'))
	sys.path.append(os.path.abspath(change_path + 'loggingMod/'))
	sys.path.append(os.path.abspath(change_path + 'configuration/'))
	sys.path.append(os.path.abspath(change_path +  '/configurationMod/'))
	sys.path.append(os.path.abspath(change_path + 'createScript/'))
	sys.path.append(os.path.abspath(change_path + 'debugModule/'))
	sys.path.append(os.path.abspath(change_path + 'writeBackModule/'))
	sys.path.append(os.path.abspath(change_path + 'duplicateDetector/'))
	sys.path.append(change_path + 'hiveSearch/')
	sys.path.append(os.path.abspath(change_path + 'mapGeneration/'))
	sys.path.append(os.path.abspath(change_path + 'upcModule/'))
	sys.path.append(os.path.abspath(change_path + 'partitionCreator/'))
	sys.path.append(os.path.abspath(change_path + 'fileSource/'))
	sys.path.append(os.path.abspath(change_path + 'itemidMetadata/'))
	return
# print function and can be modified for further update
def printing(*string):
    goingtoPrint = ""
    for each in string:
	goingtoPrint = goingtoPrint + str(each) if goingtoPrint is "" else goingtoPrint + " " + str(each)
		
    return goingtoPrint
#spark.sparkContext.addPyFile('s3://YOUR_BUCKET/spark_logging.py')
def get_logger(gv = None, logger_name = 'main'):
	app_log = gv.spark_context._jvm.org.apache.log4j.LogManager.getLogger(logger_name)
	return app_log
def set_logger_level(logger = None, app_log = None , level = 'info'):
	if level is 'info':
		app_log.setLevel(logger.Level.INFO)
	elif level is 'error':
		app_log.setLevel(logger.Level.ERROR)
	else:
		app_log.setLevel(logger.Level.DEBUG)
	return app_log
# this is the start of main function
def raiseException():
	print "Object is missing"
	raise ValueError
	return 
def mainOps(odsitem = 1 ,odsposoutletitem = 1, snapshotupdate = 1 , baseupdate = 0, mapgeneration = 1, newaddversion = 2, data_transfer = 0):
    moduleTracker = 'inside mainknitter module func mainOps'
    if len(sys.argv) == 2:
	print("Usage: snapshot detector number of days: " + str(sys.argv[1]))
    snapshot_range = int(sys.argv[1]) if len(sys.argv)  >= 2 else 1
    gv = globalVariables()
    sqlContext = initSparkContext(gv)
    hc, sqlc = hiveInit(sc_ = gv.spark_context)
    configOb = configuration.configurationFactory(sc_= gv.spark_context)
    app_logdebug = get_logger(gv = gv, logger_name = configOb.myLogger)
    app_loginfo = get_logger(gv = gv,logger_name =  configOb.myLoggerinfo)
    app_logdebug = set_logger_level(logger = gv.spark_context._jvm.org.apache.log4j, app_log = app_logdebug, level = 'debug')
    app_loginfo = set_logger_level(logger = gv.spark_context._jvm.org.apache.log4j, app_log = app_loginfo, level = 'info')
    app_logdebug.debug(moduleTracker + " line: 166 this is the begining of application")
    app_logdebug.debug(moduleTracker + " line: 167 adding all the project directories")
    addAllpath() 
    app_logdebug.debug( moduleTracker + " line: 171 stages are: " + str(configOb.stage.keys()))
    if configOb.stage['forward_tables'] is not 0:
	if configOb.stage['partitioncreator'] is 1:
		app_loginfo.info(moduleTracker + " line: 174  Start creating new partitions")
		hiveOps = hiveContextOpsforpartition(hive_context = hc, numPart = configOb.numberOfpartition)
		generatingUniformDistributionOfData(hiveOps)
		app_loginfo.info(moduleTracker + "line: 177 End of new partition creation")
	app_loginfo.info(moduleTracker + "line: 178 start forwarding the odsitem tables")
	readsnapshotBasetoupdate( spark = gv.spark_context, ranges = snapshot_range, lastFilenumber = configOb.lastFilenumbertracker[0], configOb = configOb,filtering = configOb.filter_)
	app_loginfo.info(moduleTracker + "line: 180  Start forwarding the  posoutlet table")
	updatePosoutletwithsnapshots(spark = gv.spark_context, ranges = snapshot_range, lastFilenumber = configOb.lastFilenumbertracker[1], configOb = configOb, filtering = configOb.filter_ )
	app_loginfo.info(moduleTracker + " line: 182 End of forwarding posoutlet and odsitem table")
    ## adding unique records to history database
    app_loginfo.info("start loading data")
    app_loginfo.info("after the execution we are ready")
    app_loginfo.info( "input path is: " + configOb.input_path[0]  )
    if configOb.stage['generate_map_on_latest_data'] is 1 :
	app_loginfo.info("start transfering data from hdfs to hive and start generating maps on lastest update table")
	from readandredistribute import mainOps
    	mainOps(gv.spark_context, skuM = configOb.skuM, upcM = configOb.upcM, gen_map = configOb.gen_map, table_odsitems = configOb.hivedbOb.get_tabNames(dbName_= configOb.hivedbOb.get_dbName(),index = 3 ), table_posoutlet = configOb.hivedbOb.get_tabNames(dbName_ = configOb.hivedbOb.get_dbName(), index = 2), path_names1 = configOb.input_path[0], path_names2 = configOb.input_path[1] , databasename = configOb.hivedbOb.get_dbName(), configOb = configOb, processing_tab = 'odspos'  )
	app_loginfo.info(moduleTracker + " line: 190 map generation is done")
    if configOb.stage['loadposoutlet'] is 1 :
	app_loginfo.info(moduleTracker + ":line 192 start loading the posoutlet table")
    else:
	app_loginfo.info(moduleTracker + ":line 194 skipping loading the posoutlet table ")
    
    rddOutlet, baseRddoutlet, fileListPosoutlet, listOffiles, businessSet, partitionSet, itemidRdd, rddOutletwithPartition = loadingData(data_path =  configOb.input_path[2], baseDir = configOb.input_path[0] , spark = gv.spark_context, fileType = 0, ranges = int(sys.argv[1]), odsitem = 0, businessList = configOb.businessSets, readHive = configOb.read_hive_odspos, configOb = configOb) if configOb.stage['loadposoutlet'] is not 0 else (None, None, [], None, None, None, None, None)
    if configOb.stage['loadposoutlet'] is 1:
	app_loginfo.info(moduleTracker + " :line 197 End of loading odsposoutletitem table")
    app_loginfo.info( configOb.input_path[1])
    rddOdsitem, baseRddodsitem,fileListOdsitem, _, _, _, _, _ = loadingData(data_path =  configOb.input_path[3], baseDir = configOb.input_path[1], spark = gv.spark_context,fileType = 1, ranges = int(sys.argv[1]), readHive = configOb.read_hive_odsitem, businessList = configOb.businessSets , configOb = configOb) if configOb.stage['loadodsitem'] is not 0 else (None, None, [], None, None, None, None, None)
    if configOb.stage['loadodsitem'] is 1:
	app_loginfo.info(moduleTracker + ":line 203  End of loading odsitems table")

    app_loginfo.info(moduleTracker + " :line 201 number of files need to be processed for odsitems: " + str(len(fileListOdsitem)))
    app_loginfo.info(moduleTracker + " :line 202 number of files need to be processed for odsposoutletitems: " + str(len(fileListPosoutlet)))
    app_loginfo.info(moduleTracker + " :line 206  End of loading data into system")
    #mainOps(gv.spark_context)
    ############### STEP 1 #################
    ###### search for new add from everyday image ##############
    if configOb.stage['newadditempoiddetection'] is 1:
    	app_loginfo.info(moduleTracker + " :line 210 Initiate new add search")
    	app_loginfo.info( moduleTracker + " :line 212 Initiate new add itemid, poiid and remaps detection")
    else:
	app_loginfo.info(moduleTracker + " :line 214 Skipping the new add search")
    	app_loginfo.info(moduleTracker +  " :line 215 Skipping new add itemid, poiid and remaps detection")
    ########## STEP 1 #######################
    itemid_frame, poiid_frame, remap_item, remap_poiid = getNewadds(rddOds = rddOdsitem, rddOutlet = rddOutlet, config_ = configOb, sqlContext = sqlContext, gv = gv) if newaddversion is 1 and configOb.stage['newadditempoiddetection'] is not 0 else getNewaddsv2(snapshotItemid = rddOdsitem, snapshotPoiid = rddOutlet, dictPositems = baseRddodsitem, dictPosoutlet = baseRddoutlet, spark_context = gv.spark_context, configOb = configOb, sqlc = sqlc ) if configOb.stage['newadditempoiddetection'] is not 0 else (None, None, None, None)
    #########################################
    app_loginfo.info(moduleTracker + " :line 215 End of new add itemid, poiid and remaps detection")
    app_loginfo.info(moduleTracker + " :line 220 End of new add search process ")
    ############# STEP 2 ################# 
    ########## create hive context and spark context ##############
    app_loginfo.info("Initiating hive context")
    app_loginfo.info("initiating the hive object")
    #hiveContext, sc_ = hiveContextOps.main(sc = sc)
    ############## search for affiliated upc and retrieve associated itemids #############
    print "Initiate UPC, SKU and MODEL search operation"
    try:
    	listOfItemids, dataFrameItemId = find_candidate_itemids(sc = gv.spark_context, itemid_f = itemid_frame,poiid_f = poiid_frame, config_ = configOb) if configOb.stage['upcskusearch'] is not 0 else (None, sqlc.createDataFrame(gv.spark_context.emptyRDD(), StructType([])))# upc_m = upc_map,sku_m = sku_map,model_m = model_map) # related itemid retriever 
    except TypeError , e:
	print  e
	return
    if dataFrameItemId.rdd.isEmpty() is not True:
	app_loginfo.info(moduleTracker + " :line 234 UPC search results")
    	dataFrameItemId.show()
	app_loginfo.info(moduleTracker + " :line 236 adding partition information to ")
    	dataFrameItemId = itemidTopartitionpair(baseRddoutlet, dataFrameItemId, itemidRdd = itemidRdd)
    	app_loginfo.info(moduleTracker + " :line 238 end of UPC, SKU and MODEL search process")
    	app_loginfo.info(moduleTracker + " :line 239 Itemid with partition information")
    	dataFrameItemId.show()
    #print "We are exiting here for now"
    #sys.exit(0)
    ############## STEP3  #################
    #hiveContext, sc_ = hiveContextOps.main()
    app_loginfo.info(moduleTracker +  "Initiate the hive search process")
    if dataFrameItemId.rdd.isEmpty() is True and configOb.stage["upcskusearch"] is not 0:#if listOfItemids is None:
       print "End of search operation list of new add itemids are None"
       return
    #gv.spark_context.stop()
    hiveContext, sc_ = hiveContextOps.main(sc = gv.spark_context , config = configOb, itemidRdd = dataFrameItemId ) if configOb.stage["historysearch"] is not 0 else (None, gv.spark_context)  # hive results 
    start_time = time.time()
    printing("Chosen Option is Batch Processing") if configOb.listing is 0 else printing("Chosen Option is Iterative with Loop")
    finalR = hiveContext.startDictSearch(listOfItemids,listing = int(configOb.listing)) if hiveContext is not None else sqlc.createDataFrame(gv.spark_context.emptyRDD(), StructType([]))
    finalResult = hiveContext.startFiltering(finalR,threshold = configOb.filtering_threshold) if configOb.stage['historysearch'] is not 0 else sqlc.createDataFrame(gv.spark_context.emptyRDD(), StructType([]))
    hivewb = hivewriteback(spark = gv.spark_context) if configOb.stage['updatehivetable'] is not 0 else None
    print "Write back to hdfs storage in csv format"
    app_loginfo.info("Write back to hdfs storage in csv format ")
    if finalResult.count() is not 0 and configOb.stage['writebackresults'] is 1:
    	try:
		hivewb.writeIntohdfs(finalR,pathName = configOb.output_path_history, odsitem = 0) if hivewb is not None else raiseException()
    	except (OSError, IOError ) as err:
		app_loginfo.info("final hive search is empty")
		app_loginfo.info("No history exist for this search must be new adds")
    else:
	if configOb.stage['writebackresults'] is 1:
		app_loginfo.info(moduleTracker + " Items are new adds and no related information found in history") 
		app_loginfo.info(moduleTracker + " System is exiting")
		sys.exit(0)
    app_loginfo.info(moduleTracker + " Write backe into hdfs has been done in csv format ")
    app_loginfo.info(moduleTracker +  " Total hive search time is: " + str(time.time() - start_time))
    app_loginfo.info(moduleTracker + " start updating odsitem table")
    message = updateOdsitem(snapshotRdd = rddOdsitem, baseDict = baseRddodsitem, sc = gv.spark_context, process_dict = 0, appendMode = 1, ranges = int(sys.argv[1]), hdfs_output = configOb.input_path[1] , fileList = fileListOdsitem, lastFilenumber = configOb.lastFilenumbertracker[0], configOb = configOb) if configOb.stage['updateposoutlettable'] is not 0 else "No update of odsitem table"# this is to create unique odsitem table
    app_loginfo.info(moduleTracker +  " line: 273 End of updating odsitem table operation")
    app_loginfo.info(moduleTracker + " line: 274 Returned message after updating odsitem " + message)
    app_loginfo.info( "starting updating posoutlet table")
    message = updateOdsposoutlet(snapshotRdd = rddOutlet, baseDict = baseRddoutlet, itemidRdd = itemidRdd , spark = gv.spark_context, process_dict = 0, listOffiles = listOffiles, fileList = fileListPosoutlet, ranges = int(sys.argv[1]), hdfs_output = configOb.input_path[0], rddwithPartition = rddOutletwithPartition, lastFilenumber = configOb.lastFilenumbertracker[1],configOb = configOb ) if configOb.stage['updateodsitemtable'] is not 0 else "No update of Posoutlet table"# this is to update unique odsposoutlet table
    app_loginfo.info(moduleTracker + " line: 277  Returned message after updating posoutlet table " + message)
    app_loginfo.info(moduleTracker + " line: 278 End of posoutlet table update")
    app_loginfo.info(moduleTracker + " line: 279 End of duplicate detection process")
    app_loginfo.info(moduleTracker + " line: 280 start generating the maps")
    if configOb.stage['transfer_data_to_hdfs'] is 1 :
	app_loginfo.info("start transfering data from hdfs to hive")
	from readandredistribute import mainOps
    	mainOps(gv.spark_context, writedown = 1, table_odsitems = configOb.hivedbOb.get_tabNames(dbName_= configOb.hivedbOb.get_dbName(),index = 3 ), table_posoutlet = configOb.hivedbOb.get_tabNames(dbName_ = configOb.hivedbOb.get_dbName(), index = 2), path_names1 = configOb.input_path[0], path_names2 = configOb.input_path[1] ,  databasename = configOb.hivedbOb.get_dbName(),configOb = configOb,processing_tab= 'odsitem'  )
	mainOps(gv.spark_context, writedown = 1, table_odsitems = configOb.hivedbOb.get_tabNames(dbName_= configOb.hivedbOb.get_dbName(),index = 3 ), table_posoutlet = configOb.hivedbOb.get_tabNames(dbName_ = configOb.hivedbOb.get_dbName(), index = 2), path_names1 = configOb.input_path[0], path_names2 = configOb.input_path[1] ,  databasename = configOb.hivedbOb.get_dbName(),configOb = configOb,processing_tab = 'odspos'  )
	app_loginfo.info(moduleTracker + " line: 296 End of transfering the data")
    app_loginfo.info(moduleTracker + " Start generating the map processing")
    message = generateMaps(baseDict = baseRddoutlet, spark = gv.spark_context ,upcM = 1,skuM = 1,upc_map_dir = configOb.root_mapper['upclim'],sku_map_dir = configOb.root_mapper['skulim']) if configOb.stage['creatingmap'] is not 0 and baseRddoutlet is not None else "incomplete map generation for None type base"
    print message
    app_loginfo.info(moduleTracker + " line: 283 End of map generation process")
    app_loginfo.info(moduleTracker +  " line: 285 End of the processing daily snapshot")
    app_loginfo.info(moduleTracker + " line: 286 application successfully Ends")
    ################## STEP 4 ####################
    return
def loadDatabeforestart():
	snapshotPositem, baseDictpositem = loadData(data_path = '/npd/ODS/ODS_INPUTS_BZ2/ODS_POSITEMS/',readHdfs = 1 )
	return
if __name__ == "__main__":
    #print(inspect.getsource(logging))
    logger1 = logging.getLogger("")
    logger1.info("Start of the dictionary operation from main module")
    #mainOps()
    logger1.info("End of the dictioanry operation")
    logger1.info("Application exiting after completion of work")
    logger1.info("End of dictionary operation")
