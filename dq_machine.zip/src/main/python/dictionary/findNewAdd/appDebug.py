#!/usr/bin/env python

import os
import sys
from functools import wraps
#import lazy_property
def reasonBehindExit(msg):
	print "Application is going to exit"
	print(msg)
	print " return"
	return 1
def reasonOfException(msg, handler = None):
	if handler is not None:
		handler.info(msg)
	else:
		print "There is exception occured"
		print(msg)
		print "return"
	return 2
def genericException(msg):
	return msg
def get_functions(_type):
	if _type is 0:
		return reasonBehindExit
	elif _type is 1:
		return reasonOfException
	else:
		return genericException 
	
def get_reasons(switching, msg, _type):
	if(switching.get(_type) == None):
		switching[_type] = get_funcitonss(_type)
	else:
		return switching.get(_type)
	
def applicationDebugModule(msg = None, _type = 0):
	#@lazy_property.LazyProperty
	switching = { }
	return  switching
