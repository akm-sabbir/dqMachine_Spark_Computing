# ##########################
# ##########################
#
# Module to find new adds in itemids with associated POIIDs
# from Sqooped data
#
# ##########################
# ##########################

import sys
import datetime
import os
import numpy as np
from collections import defaultdict
from collections import namedtuple
import pyspark.sql.functions as psf
from pyspark.sql import Row
import spark_logging as logging 
from pyspark.sql.functions import min, max 
import pyspark
from py4j.protocol import Py4JJavaError
import dictstatus_db
import MySQLdb
import spark_logging as logging
import time
import datetime
from pyspark.sql.functions import lit
from pyspark.sql.types import *
from pyspark.sql.types import DoubleType
sys.path.append(os.path.abspath('../fileSystem/'))
from hdfsFileDiscovery import deletePath
from changedItems import getChangedItemsforpoiid
from changedItems import getChangedItemsforitemid
import time
from time import gmtime, strftime
from mysqlWriteback import mysqlWriteback
from  spark_logging import Unique
from spark_logging import Unique
from dynamicRepartition import dynamicRepartition
debug = False
spark_context = None
dict_status = None
#class globalVariables(object):
#	def __init__(self):
#		self.debug = False
#4		self.spark_context = None
#		self.dict_status = None
globalVar = None #globalVariables()
def setupDatabase():
    js = dictstatus_db.dictstatus_db()
    js.set_hostname('lslhdpcd1.npd.com')
    js.set_database('PACEDICTIONARY')
    js.set_table('DICTIONARY_STATUS')
    js.set_primary_key_name('CHANGE_ID')
    js.get_setup()
    return js

### spark initiation operation
def initSparkContext():
    #global globalVar.spark_context
    conf = SparkConf()
    conf.set("spark.dynamicAllocation.enabled",True)
    conf.set("spark.yarn.executr.memoryOverhead",8192)
    conf.set("spark.shuffle.service.enabled",True)
    conf.set("yarn.nodemanager.vmem-check-enabled",False)
    conf.set("spark.local.dir","/hdpdata/tmp")
    conf.set("yarn.nodemanager.vmem-pmem-ratio",6)
    conf.set("spark.eventLog.enabled",True)
    conf.set("spark.driver.memory",128)
    conf.set("spark.eventLog.dir","/hdpdata/logs")
    conf.set("spark.serializer","org.apache.spark.serializer.KryoSerializer")
    globalVar.spark_context = SparkContext(conf = conf)
    globalVar.spark_context.setLogLevel("ERROR")
    sqlContext = SQLContext(globalVar.spark_context)
    return sqlContext

### filename reformatting 
def fileNameFormatting(fileName = None,compreT = 'gz'):
    if(fileName is None):
        raise TypeError
        return
    filenumber = int(fileName.split('-m-')[1].replace('.' + compreT,'')) + 1 # previously it was .gz
    fileName = fileName.split('-m-')[0]+'-m-'
    fileName = fileName+'{:05}'.format(filenumber) + '.' + compreT # previously it was .gz
    print "FileName to be processed is : " + fileName
    return fileName,filenumber

### read from csv file file name need to be mentioned

def readDataFromCsvFile(filename = None,sqlContext = None):
    #global globalVar.spark_context
	
    try:
        rdd1 = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("header", "true").option("delimiter","|").option("quote","\\").option("codec","bzip2").option("treatEmptyValuesAsNulls","true").option("nullValue",None).load(filename).repartition(50)
        return rdd1
    except Py4JJavaError as e :
	print("invalid path name for data source")
	return None
    except (OSError,IOError, ValueError) as e :
        print e
        print('No file found '+str(ifile))
        return None
    except pyspark.sql.utils.AnalysisException as e:
	print e
	return None
    return  None

### time reformatting using string formatting technique
def createTimeFormatting( timeFmt = "yyyy-mm-dd'T'HH:mm:ss.SSS", timeScale = 86400 ):
    timeDiff = (funcs.unix_timestamp('UPDATE_DATE', format = timeFmt) - funcs.unix_timestamp('ADDED_DATE', format = timeFmt))/(timeScale*1.0)
    return timeDiff

### change from rdd to dataframe
def changeToDataFrame(rdd = None):
    return rdd.toDF()

### perform filtering operation on dataframe
def filterOutItemidWithZero(dataFrame = None):
    return dataFrame.filter(dataFrame.ITEM_ID > 0)

def printKeyValues(dict_):
    for k,v in dict_.items():
        print "Key: " + str(k) + " " + "Value: " + str(v)
    return

### reformattting function  essential
def reformattingDomainName(fileName = None, oldcomp = "gz", newcomp = "gz"):
	global globalVar
	if globalVar.debug is True:
		print fileName	
	comp = fileName.split('/')
	if globalVar.debug == True:
		print comp
	#comp[2] = 'lslhdprsdn02'
	# complicated rules better to avoid the whole thing
	if(oldcomp != newcomp):
		comp[len(comp) - 1] = str(comp[len(comp)-1]).replace(str(oldcomp),str(newcomp))#(oldcomp, newcomp)
	#if(comp.count('old_ods') == 0):
		#comp[2] = 'old_ods'
	result = comp[:2] + (['test'] if comp.count('test')  is  0 else [] ) + comp[2:]
	print result
	return ("/").join(result)
def get_partition_number(rdd, resizer, th):
	actualSize = rdd.rdd.getNumPartitions()
	if(abs(resizer-actualSize) < th):
		return 0
	else:
		return resizer
def findNewitemsandoutlet(rddItems, rddPosoutlet, dictPositems, dictPosoutlet,filterPoiid = 1, joinType = 'leftanti', dp = None ,th = 5):
	#rddItems = rddItems.withColumn("itemid",rddItems["itemid"].cast("long"))
	#dictPositems = dictPositems.withColumn("itemid",dictPositems["itemid"].cast("long"))
	newaddItemids = rddItems.alias('rddItems').join(dictPositems.alias("dictPositems"), psf.col("rddItems.itemid") == psf.col("dictPositems.itemid"),joinType).distinct()
	#rddPosoutlet = rddPosoutlet.withColumn("poi_id",rddPosoutlet["poi_id"].cast("long"))
	#dictPosoutlet = dictPosoutlet.withColumn("poi_id",dictPosoutlet["poi_id"].cast("long"))
	newaddPoiids = rddPosoutlet.alias('rddPos').join(dictPosoutlet.alias("dictPos"),psf.col("rddPos.poi_id") == psf.col("dictPos.poi_id"),joinType).distinct()
        newadditemids = newaddItemids.count()
	dp.set_data_size(newadditemids)
	resizer = dp.dynamicPartitionresizer()
	actualSizeitem = get_partition_number(newaddItemids, resizer, th )
        print "New add itemids count : " + str(newadditemids)
	#print "new add poiid count: " + str(newaddPoiids.count())
	#newaddPoiids = newaddPoiids.withColumn("itemid",newaddPoiids["itemid"].cast("long"))
	newaddPoiids = newaddPoiids.alias("newaddP").join(newaddItemids.alias("newaddI"), psf.col("newaddP.itemid") == psf.col("newaddI.itemid"), "inner").select("newaddP.*") if filterPoiid is 1 else newaddPoiids
	newaddpoiids = newaddPoiids.count()
	dp.set_data_size(newaddpoiids)
	resizer = dp.dynamicPartitionresizer()
	actualSizepos = get_partition_number(newaddPoiids, resizer, th )
	print "Filtered new poiid count " +str(newaddpoiids)
	newaddItemids = newaddItemids.repartition(actualSizeitem) if actualSizeitem is not 0 else newaddItemids
	newaddPoiids = newaddPoiids.repartition(actualSizepos) if actualSizepos is not 0 else newaddPoiids
	return newaddItemids, newaddPoiids
# this is remaps or maps retrieval function
def getMapsfromnewadd(rddItems = None , newaddItemids = None, rddPosoutlet = None, newaddPoiids = None, debug = True, dp = None, th = 5):
	#rddItems = rddItems.withColumn("itemid",rddItems["itemid"].cast("long"))
	#newaddItemids = newaddItemids.withColumn("itemid",newaddItemids["itemid"].cast("long"))
	if debug is True:
		print "Start of remap detection for new add itemids and poiids "
	rddRemaps = rddItems.alias("rddItems").join(newaddItemids.alias("newadd"),psf.col("rddItems.itemid") == psf.col("newadd.itemid"),"leftanti")
	#rddPosoutlet = rddPosoutlet.withColumn("poi_id",rddPosoutlet["poi_id"].cast("long"))
	#newaddPoiids = newaddPoiids.withColumn("poi_id",newaddPoiids["poi_id"].cast("long"))
	rddPoiidremap = rddPosoutlet.alias('rddPos').join(newaddPoiids.alias("newaddP"),psf.col("rddPos.poi_id") == psf.col("newaddP.poi_id"),"leftanti")
	rdditemCount = rddRemaps.count()
	dp.set_data_size(rdditemCount)
	resizer = dp.dynamicPartitionresizer()
	actualSizeitem = get_partition_number(rddRemaps, resizer, th )
        #print "new add itemids count : " + str(rdditemCount)
	rddpoiidCount = rddPoiidremap.count()
	dp.set_data_size(rddpoiidCount)
	resizer = dp.dynamicPartitionresizer()
	actualSizepoiid = get_partition_number(rddPoiidremap, resizer, th )

	if debug is True:	
		print "Remaps count for itemid: " + str(rdditemCount)
		print "Remaps count for poiid: " + str(rddpoiidCount)
	rddRemaps = rddRemaps.repartition(actualSizeitem) if actualSizeitem is not 0 else rddRemaps
	rddPoiidremap = rddPoiidremap.repartition(actualSizepoiid) if actualSizepoiid is not 0 else rddPoiidremap # for big data 260
	if debug is True:
		print "End of the remap detection for new add itemids and poiids"
	return rddRemaps, rddPoiidremap
def filterMapswithand(remapsItemid = None , remapsPoiid = None , dictPositems = None , dictPosoutlet = None, debug = True):
	print "This is an unnecessary function"
	if debug is True:
		print "Filtering out the"
	dictPositems = dictPositems.alias("rddItems").join( remapsItemid.alias("newadds"), psf.col("rddItems.itemid") == psf.col("newadds.itemid"), "inner").select("rddItems.*")
        remapsItemid = remapsItemid.alias("newadds").join( dictPositems.alias("rddItems"), psf.col("newadds.businessid") == psf.col("rddItems.businessid") , "leftanti")	
	remapsItemid = remapsItemid.alias("newadds").join( dictPositems.alias("rddItems"), psf.col("newadds.subcategoryn") == psf.col("rddItems.subcategoryn") , "leftanti")
	remapsItemid = remapsItemid.alias("newadds").join( dictPositems.alias("rddItems"), psf.col("newadds.itemnumber") == psf.col("rddItems.itemnumber") , "leftanti")
	dictPosoutlet = dictPosoutlet.alias("rddItems").join(remapsPoiid.alias("newadds"), psf.col("rddItems.poi_id") == psf.col("newadds.poi_id"), "inner").select("rddItems.*")
	remapsPoiid = remapsPoiid.alias("newadds").join(dictPosoutlet.alias("rddItems"), psf.col("newadds.business_id") == psf.col("rddItems.business_id"),  "leftanti")
	remapsPoiid = remapsPoiid.alias("newadds").join(dictPosoutlet.alias("rddItems"), psf.col("newadds.itemid") == psf.col("rddItems.itemid"),  "leftanti")
	return remapsItemid, repmapsPoiid

def filterMaps(remapsItemid = None , remapsPoiid = None , dictPositems = None , dictPosoutlet = None, debug = True):
	if debug is True:
		print "start of filtering out the remaps based on attributes"
	matchList = [ psf.col("newadds.businessid") == psf.col("rddItems.businessid") , psf.col("newadds.subcategoryn") == psf.col("rddItems.subcategoryn") , psf.col("newadds.itemnumber") == psf.col("rddItems.itemnumber") ]
	matchList2 =  psf.col("rddItems.itemid") == psf.col("newadds.itemid") #, psf.col("rddItems.businessid") == psf.col("newadds.businessid") , psf.col("rddItems.subcategoryn") == psf.col("newadds.subcategoryn") , psf.col("rddItems.itemnumber") == psf.col("newadds.itemnumber") ]
	dictPositems = dictPositems.alias("rddItems").join( remapsItemid.alias("newadds"), psf.col("rddItems.itemid") == psf.col("newadds.itemid"), "inner").select("rddItems.*")
	remapsItemidsbid = remapsItemid.alias("newadds").join( dictPositems.alias("rddItems"), matchList[0], "leftanti")	
	remapsItemidssub = remapsItemid.alias("newadds").join( dictPositems.alias("rddItems"), matchList[1], "leftanti")	
	remapsItemiditem = remapsItemid.alias("newadds").join( dictPositems.alias("rddItems"), matchList[2], "leftanti")

	if debug is True:
		print "count of actual remapsItemid after filtering: " + str(remapsItemid.count())
	matchListpos = [ psf.col("newadds.business_id") == psf.col("rddItems.business_id") , psf.col("newadds.itemid") == psf.col("rddItems.itemid") ]
	matchListpos2 =  psf.col("rddItems.poi_id") == psf.col("newadds.poi_id")#, psf.col("rddItems.business_id") == psf.col("newadds.business_id") , psf.col("rddItems.itemid") == psf.col("newadds.itemid")]
	dictPosoutlet = dictPosoutlet.alias("rddItems").join(remapsPoiid.alias("newadds"), psf.col("rddItems.poi_id") == psf.col("newadds.poi_id"), "inner").select("rddItems.*")
	remapsPoiidsbid = remapsPoiid.alias("newadds").join(dictPosoutlet.alias("rddItems"), matchListpos[0] , "leftanti")
	remapsPoiidsitem = remapsPoiid.alias("newadds").join(dictPosoutlet.alias("rddItems"), matchListpos[1] , "leftanti")
	#remapsItemid = remapsItemid.repartition(260)
	#remapsPoiid  = remapsPoiid.repartition(260)
	if debug is True:
		print "Count of the actual remapsPoiid after Filtering: " + str(remapsPoiid.count())
		print "End of the filtering out remaps based on attributes"
	return (remapsItemidsbid, remapsItemidssub, remapsItemiditem), (remapsPoiidsbid, remapsPoiidsitem)

# careful about setting the threshold value
def startFiltering(rdd, threshold = 20000):
	print "Start filtering out the extraneous ref itemids"
	rddTemp = rdd.groupBy("itemid").count().select(psf.col("itemid").alias("itemid_"),psf.col("count").alias("count_"))
	rddTemp = rddTemp.where(rddTemp.count_ < threshold)
	rdd = rdd.alias("rdd").join(rddTemp.alias("rddTemp"), psf.col("rdd.itemid") == psf.col("rddTemp.itemid_"), "inner")
	rdd = rdd.drop("itemid_")
	rdd = rdd.drop("count_")
	print "End of the filtering out the extraneous ref itemids"
	return rdd 

def findRefpoiid(remapRdd, baseRdd, filtering_param,th):
	print "Start of the finding the ref poiids"
	paramList = []
        for each in filtering_param:
		paramList.append(psf.col("rddItems." + each) == psf.col("remapRdd." + each))	
	refRdd = baseRdd.alias("rddItems").join(remapRdd.alias("remapRdd"), paramList, "inner").select("rddItems.*")
        refRdd = startFiltering(refRdd, threshold = th)
	print "End of the finding the ref poiids"
	return refRdd

# this following function is for adding up the fragmented rdds
def unionAlldf(df,sqlc = None, sc_ = None):
	result = sqlc.createDataFrame(sc_.emptyRDD(),StructType([]))
	for column in df[0].columns:
		result  = result.withColumn(column,lit(None))
	for each in df:
		result = result.unionAll(each)
	return result

# initiate process to detect the new adds and store them in database
# following function is obsolete
 
def readMySql(sc_ = None):
	pushdown_query = "select * from PACEDICTIONARY"
	connectionProps ={"usr":"root","password":"My$qlD","driver":"com.mysql.jdbc.Driver"}
	timeZone = "UTC"
	hostname = "lslhdpcd1"
	portname = 3306
	username= "root"
	dbname= "PACEDICTIONARY"
	password = "My$qlD"
	zeroDateTimeBehavior= "convertToNull"
	#jdbc_url = "jdbc:mysql://lslhdpcd1:3306/PACEDICTIONARY?serverTimezone=UTC"
	jdbc_url = "jdbc:mysql://{0}:{1}/{2}?user={3}&password={4}&serverTimezone={5}&zeroDateTimeBehavior={6}".format(hostname,portname,dbname,username,password,timeZone,zeroDateTimeBehavior)	
	df = sc_.read.jdbc(url = jdbc_url,table = "DICTIONARY_STATUS",properties = connectionProps)
	#df.show()
	return df 

# main function the entry point for this module
def writeBackto(rdd,path):
    #deletePath(path,globalVar.spark_context)
    rdd.write.format("com.databricks.spark.csv").option("inferSchema","true").option("header", "true").option("delimiter", "|").option("quote","\\").option("codec","bzip2").option("treatEmptyValuesAsNulls","true").option("nullValue",None).save(path)
    return
def generateStats(snapshots, newaddItems, remapsItems, attrib, dateCol, _type):
    min_date, max_date = snapshots.select(psf.min(dateCol),psf.max(dateCol)).first()
    #snapshots = snapshots.withColumn("EARLIEST_TIME_STAMP", lit(min_date))
    #snapshots = snapshots.withColumn("LATEST_TIME_STAMP",lit(max_date))
    #snapshots = snapshots.withColumn("PROCESSING_TIME",lit(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    #snapshotsT = snapshots.select(psf.col(attrib).alias('businessid'), "EARLIEST_TIME_STAMP","LATEST_TIME_STAMP","PROCESSING_TIME").distinct()
    snapshotsC = snapshots.groupBy(attrib).count().select(psf.col(attrib).alias("businessid"), psf.col("count").alias("countS"))
    newaddC = newaddItems.groupBy(attrib).count().select(psf.col(attrib).alias("businessid"), psf.col("count").alias("countN"))
    remapsitemsC = remapsItems.groupBy(attrib).count().select(psf.col(attrib).alias("businessid"), psf.col("count").alias("countR"))	
    snapshotsC = snapshotsC.alias("snapshotsC").join(newaddC.alias("newaddC"), psf.col("snapshotsC.businessid") == psf.col("newaddC.businessid"),"inner").select(psf.col("snapshotsC.businessid").alias("businessid"), psf.col("countS").alias("Sqoop_total"), psf.col("countN").alias("NewAdds"))
    snapshotsC = snapshotsC.alias("snapshotsC").join(remapsitemsC.alias("remapsitemsC"), psf.col("snapshotsC.businessid") == psf.col("remapsitemsC.businessid"),"inner").select(psf.col("snapshotsC.businessid").alias("businessid"), "Sqoop_total", "NewAdds",psf.col("countR").alias("Mapping"))
    snapshotsC = snapshotsC.withColumn("EARLIEST_TIME_STAMP",lit(min_date))
    snapshotsC = snapshotsC.withColumn("LATEST_TIME_STAMP",lit(max_date))
    snapshotsC = snapshotsC.withColumn("PROCESSING_TIME_STAMP",lit(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    snapshotsC = snapshotsC.withColumn("EARLIEST_TIME_STAMP",snapshotsC["EARLIEST_TIME_STAMP"].cast("timestamp"))
    snapshotsC = snapshotsC.withColumn("LATEST_TIME_STAMP",snapshotsC["LATEST_TIME_STAMP"].cast("timestamp"))
    snapshotsC = snapshotsC.withColumn("PROCESSING_TIME_STAMP",snapshotsC["PROCESSING_TIME_STAMP"].cast("timestamp"))
    snapshotsC = snapshotsC.filter(psf.col("businessid").isNotNull())
    snapshotsC = snapshotsC.withColumn("STATUS",lit("UNKNOWN"))
    snapshotsC = snapshotsC.withColumn("DATATYPE",lit(_type))
    # this will go into logging info
    # snapshotsC.printSchema()
    #snapshotsT = snapshotsT.alias("snapshotsT").join(snapshotsC.alias("snapshotsC"), psf.col("snapshotsT.businessid") == psf.col("snapshotsC.businessid"),"inner").select(psf.col("snapshotsC.businessid").alias("businessid"), "countS", "EARLIEST_TIME_STAMP", "LATEST_TIME_STAMP", "PROCESSING_TIME")
    #snapshotsT = snapshotsT.alias("snapT").join(newaddC.alias("newaddC"),psf.col("snapT.businessid") == psf.col("newaddC.businessid"),"inner").select(psf.col("snapT.businessid").alias("businessid"), "countN", "countS", "EARLIEST_TIME_STAMP", "LATEST_TIME_STAMP", "PROCESSING_TIME")
    #snapshotsT = snapshotsT.alias("snapT").join(remapsitemsC.alias("remaps"), psf.col("snapT.businessid") == psf.col("remaps.businessid"),"inner").select(psf.col("snapT.businessid").alias("BUSINESS_ID"),psf.col("countS").alias("TOTAL_SQOOP"),psf.col("countN").alias("NEW_ADDS"),psf.col("countR").alias("MAPPING"),"PROCESSING_TIME","EARLIEST_TIME_STAMP","LATEST_TIME_STAMP")
    run_id = datetime.datetime.now().strftime("%Y%m%d")
    dtime = datetime.datetime.now()
    if dtime.hour < 12 :
	run_id = run_id + "_AM"
    else:
	run_id = run_id + "_PM"
    snapshotsC = snapshotsC.withColumn("Run_ID",lit(run_id))
    '''
    type_of_data = ['itemid','poiid']
    dictionary = {'itemid':positemStat, 'poiid':posoutletStat}
    with open('src/main/python/dictionary/fileSource/statOutput','w+') as datawriter:
	for each in type_of_data:
		dataList = dictionary[each] 
		for datum in dataList:
			datawriter.write('{}\n'.format(each  + '\t' + str(datum[0]) + '\t' + str(datum[1]))) #if each is 'itemid' else datawriter.write('{}\n'.format(each + '\t' + datum.business_id+ '\t' + datum.count()))
    '''
    return snapshotsC, run_id
def writeBackresults(rdd , path = None , sub_path = ['itemnumber','itemid'], addC = False, sqlc = None, sc_ = None, processingDate = None):
	date, hour = processingDate.split(" ")
	run_id = date #datetime.datetime.strptime(date,'%Y%m%d')#datetime.datetime.now().strftime("%Y%m%d")
	dhour = int(hour)
    	#dtime = datetime.datetime.now()
    	if dhour < 12 :
		run_id = run_id + "_AM"
	else:
		run_id = run_id + "_PM"
	if isinstance(rdd,tuple) is False:
		deletePath(path + '/' + sub_path[0] + '/' + run_id , sc_ = sc_)
		#rdd = rdd.withColumn("partitioner", rdd["itemid"].cast("long"))
		#rdd = sparkTopandas(rdd)
		# following statement retrieve the last two digits from itemid and d
		#rdd["partitioner"]  = rdd["partitioner"].astype(str).str[-2:]#.astype(np.int64)
        	#tempVar = pandasTospark(tempVar, sqlc)
		writeBackto(rdd, path + '/' + sub_path[0] + '/' + run_id)
		return
	for ind, each in enumerate(rdd):
		deletePath(path + '/' + sub_path[ind] + '/' + run_id , sc_ = sc_)
		tempVar = each.withColumn("partitioner", each["itemid"].cast("long"))
		if tempVar.rdd.isEmpty() is False:
			tempVar = sparkTopandas(tempVar)
			# following statement retrieve the last two digits from itemid and d
			tempVar["partitioner"]  = tempVar["partitioner"].astype(str).str[-2:]#.astype(np.int64)
        		tempVar = pandasTospark(tempVar, sqlc)
		#each = addingExtraColumn(each, sqlc = sqlc )
		writeBackto(tempVar, path + '/' + sub_path[ind] + '/' + run_id)
		
	return
def addingExtraColumn(rdd, columnName_ = 'itemid', newcolumnName = 'partitioner', sqlc = None):
	rdd = rdd.withColumn("partitioner", rdd["itemid"].cast("long"))
	rdd = sparkTopandas(rdd)
	# following statement retrieve the last two digits from itemid and d
	rdd[newcolumnName]  = rdd[newcolumnName].astype(str).str[-2:].astype(np.int64)
        rdd = pandasTospark(rdd, sqlc)
	return rdd

def sparkTopandas(rdd):
	rdd = rdd.toPandas()
	return rdd

def pandasTospark(rdd,sqlc):
	rdd = sqlc.createDataFrame(rdd)
	return rdd
# this is the new add version function 
def getNewaddsv2(snapshotItemid = None, snapshotPoiid = None, dictPositems  = None , dictPosoutlet = None, spark_context = None, configOb = None, sqlc = None, debug = False ):
	print "Start detecting the new adds"
	moduleTracker = "findNewAdd module getNewaddsv2 function line "	
	if configOb is None:
		print "ConfigOb can not be null else system will not be initialized"
		print "Essential parameter can not be null"
		print "Processing is exiting here"
		sys.exit(0)
	if spark_context is None:
		print "There is an issue"
		print "spark context can not be null"
		print "Processing exiting"
		sys.exit(0)
	newadd_logger = configOb.get_logger( logger_name = configOb.myLoggerinfo)
	newadd_logger = configOb.set_logger_level(logger = spark_context._jvm.org.apache.log4j, app_log = newadd_logger, level = 'info')
	newadd_logger.info(moduleTracker + " Creating dynamic repartition function")
	dynamicPartitiongenerator = dynamicRepartition.factoryFunc(file_name = 'src/main/python/dictionary/configuration/resource_config')
	newaddItems, newaddPos = findNewitemsandoutlet(rddItems = snapshotItemid, rddPosoutlet = snapshotPoiid, dictPositems = dictPositems, dictPosoutlet = dictPosoutlet,filterPoiid = 1, joinType = 'leftanti',dp = dynamicPartitiongenerator, th = configOb.partition_size_change)
	itemsRemap, poiidRemaps = getMapsfromnewadd(rddItems = snapshotItemid, newaddItemids = newaddItems, rddPosoutlet = snapshotPoiid, newaddPoiids = newaddPos, dp = dynamicPartitiongenerator, th = configOb.partition_size_change)
	remapItemstups, remapPoiidtups = filterMaps(remapsItemid = itemsRemap, remapsPoiid = poiidRemaps , dictPositems = dictPositems , dictPosoutlet = dictPosoutlet)
	writeBackresults(remapItemstups, path = configOb.change_dir, sub_path = ['businessid','subcategoryn','itemnumber'], addC = True, sqlc = sqlc, sc_ = spark_context, processingDate = configOb.processingDate)
	writeBackresults(remapPoiidtups, path = configOb.change_dir, sub_path = ['businessid','itemid'], addC = True, sqlc = sqlc, sc_ = spark_context, processingDate = configOb.processingDate )
	rRemapItems = unionAlldf(remapItemstups, sqlc = sqlc, sc_ = spark_context )
	rRemapPoiid = unionAlldf(remapPoiidtups, sqlc = sqlc, sc_ = spark_context )
        refPoiid = findRefpoiid(rRemapPoiid, dictPosoutlet, filtering_param = ["itemid","manufacturercode"],th = configOb.filtering_threshold)
	print "start of second ref poiid calculation"
	refPoiid2 = findRefpoiid(rRemapPoiid, dictPosoutlet, filtering_param = ["itemid"],th = configOb.filtering_threshold)
	print "End of finding reference poiids"
	print "Start writing back the results"
	writeBackresults(refPoiid, path = configOb.change_dir, sub_path = ['refPoiid'], sc_ = spark_context, processingDate = configOb.processingDate)
	writeBackresults(refPoiid2, path = configOb.change_dir, sub_path = ['refPoiid2'], sc_ = spark_context, processingDate = configOb.processingDate)
	print "End of writing back the ref results"
	newadd_logger.info("Generating the stats for snapshotitemids")
	stats, run_id = generateStats(snapshotItemid, newaddItems, rRemapItems, "businessid", "updated", "itemid")
	newadd_logger.info("generating the stats for snapshotpoiids")
	stats2, run_id = generateStats(snapshotPoiid, newaddPos, rRemapPoiid, "business_id", "updated", "poiid")
	deletePath(configOb.output_path_newadditem +'/' + run_id , sc_ = spark_context)
	deletePath(configOb.output_path_newaddpoiid + '/' + run_id , sc_ = spark_context)
	writeBackto(stats, configOb.output_path_newadditem + '/' + run_id)
    	writeBackto(stats2, configOb.output_path_newaddpoiid + '/' + run_id)
	if debug is True:
	        mysqlWrite = mysqlWriteback(config_path = "src/main/python/dictionary/configuration/mysqlProperties", mode = "append" )
        	mysqlWrite.initiate_ops()
        	mysqlWrite.writingBack(stats)
		mysqlWrite.writingBack(stats2)
	return newaddItems, newaddPos, rRemapItems, rRemapPoiid
# old version of new adds
def timenow():
    return(' ' + str(datetime.datetime.now()).split('.')[0])

def initOps(Ops = 1):
    if Ops is 1:
	return setupDatabase()
    else:
	return initSparkContext()
    #return setupDatabase() if Ops is 1 else initSparkContext()

def initProcess(rdd = None, js = None, sqlContext = None, choice = 0, new_itemids = None, new_poiids = None,use_db = True, itemidFrame = None, poiidFrame = None,config_ = None):
    #if(js == None and sqlContext == None):
    if js is None:
    	js = initOps(Ops = 1) 
    if sqlContext  is None:
    	sqlContext = initOps( Ops = 2)
    if js is None:
	print "JS is the database object which is None"
	print js
    if sqlContext is None:
	print "sqlContext is essential component and can not be None"
	print "None SqlContext means the application is going to fail at some point later"
	print ("So we are exiting right now")
	sys.exit(1)
    	#print sqlContext
    print('Processing NEW ITEMID stage ' + str(choice))
    if choice is 0:
	print "New add itemid detection stage"
        idlist, latest_file_number , idframe = process(rdd = rdd, js = js, sqlContext = sqlContext, _type = 'ITEMID', _change_type = 'NewAdd', config_ = config_)
        return (idlist , latest_file_number , idframe, js,sqlContext)
    elif choice is 1:
	print "New add poiid detection stage"
        idlist , latest_file_number, idframe = process(rdd = rdd, js = js, sqlContext = sqlContext, _itemid_list = new_itemids, _type = 'POIID', _change_type = 'NewAdd',itemidFrame = itemidFrame, config_ = config_)
	return (idlist , latest_file_number , idframe)
    else:
	print "New Remaps statistics generation"
        idlist, latest_file_number , idframe = process(rdd = rdd, js = js, sqlContext = sqlContext, _itemid_list = new_itemids, _poiid_list = new_poiids, _type = 'POIID', _change_type = 'NewAddRemap',itemidFrame = itemidFrame, poiidFrame = poiidFrame,config_ = config_)
  	return ( idlist , latest_file_number , idframe )

# column renaming conventions
def renamingColumns(*colnames):
	r = []
	for ind,each in enumerate(colnames):
		r.append('_c' + str(ind)+ ' as ' + each)
	return r


# this is only for testing purpose works on written back data in hdfs
def testMain():
	js = initOps(Ops = 1) 
	sqlContext = initOps( Ops = 2)
	itemidDataframe = readDataFromCsvFile(filename ='/npd/test/ODS/s_test/itemidFrame',sqlContext = sqlContext)
	#r = renamingColumns('BUSINESS_ID', 'ITEM_ID', 'SUB_CATEGORY', 'ITEMNUMBER', 'ADDED_DATE', 'UPDATE_DATE')
	#r = renamingColumns(liC)
	#itemidDataframe = itemidDataframe.selectExpr(r)
	poiidDataframe  = readDataFromCsvFile(filename ='/npd/test/ODS/s_test/poiidFrame',sqlContext = sqlContext)	
	remapDataframe  = readDataFromCsvFile(filename = '/npd/test/ODS/s_test/remapFrame',sqlContext = sqlContext)
	#r = renamingColumns(liC)
	#remapDataframe = remapDataframe.selectExpr(r)
	return globalVar.spark_context, itemidDataframe, poiidDataframe, remapDataframe

def getNewadds(rddOds = None,rddOutlet = None, config_ = None, sqlContext = None, gv = None,writeB = 0):
    global globalVar
    globalVar = gv
    #global globalVar.spark_context
    # retrieving itemids through first call to the processing function
    itemidList, latest_file_number, itemidDataframe, js, sqlContext = initProcess(rdd = rddOds, config_ = config_,sqlContext = sqlContext)
    print "latest file number for itemid: " + str(latest_file_number)
    if itemidDataframe.rdd.isEmpty() is True:
	print "after stage 1 new itemid list is None so exit"
	return
    poiidList, latest_file_number, poiidDataframe = initProcess(rdd = rddOutlet, js = js, sqlContext = sqlContext , choice = 1, new_itemids = itemidList, itemidFrame = itemidDataframe, config_ = config_)
    if poiidDataframe.rdd.isEmpty() is True:
	print "POIIDs  are None need to break out"
	return
    # New add remaps from the third call of processing function with choice 2 
    _, latest_file_number, remapDataframe = initProcess(rdd = rddOutlet, js = js,sqlContext = sqlContext, choice = 2, new_itemids = itemidList,new_poiids = poiidList,itemidFrame = itemidDataframe, poiidFrame = poiidDataframe, config_ = config_)
    print "UPC and SKU we are going to look for"
    positemStat = itemidDataframe.groupBy('BUSINESS_ID').count().select("BUSINESS_ID","count").collect()
    #positemStat = positemStat.rdd.map(lambda x : (x.BUSINESS_ID,x.count)).collect()
    posoutletStat = poiidDataframe.groupBy('BUSINESS_ID').count().select("BUSINESS_ID","count").collect()
    #posoutletStat = posoutletStat.rdd.map(lambda x: (x.BUSINESS_ID, x.count)).collect()
    type_of_data = ['itemid','poiid']
    dictionary = {'itemid':positemStat, 'poiid':posoutletStat}
    with open('src/main/python/dictionary/fileSource/statOutput','w+') as datawriter:
	for each in type_of_data:
		dataList = dictionary[each] 
		for datum in dataList:
			datawriter.write('{}\n'.format(each  + '\t' + str(datum[0]) + '\t' + str(datum[1]))) 
		#if each is 'itemid' else datawriter.write('{}\n'.format(each + '\t' + datum.business_id+ '\t' + datum.count()))
    if writeB is 1:
	deletePath('/npd/test/ODS/s_test/itemidFrame/',sc_ = globalVar.spark_context)
	deletePath('/npd/test/ODS/s_test/poiidFrame/',sc_ = globalVar.spark_context)
	deletePath('/npd/test/ODS/s_test/remapFrame/',sc_ = globalVar.spark_context)
	writeBackto(itemidDataframe,'/npd/test/ODS/s_test/itemidFrame/')
    	writeBackto(poiidDataframe,'/npd/test/ODS/s_test/poiidFrame/')
    	writeBackto(remapDataframe,'/npd/test/ODS/s_test/remapFrame/')
    return  itemidDataframe, poiidDataframe, remapDataframe, None

def process(rdd = None, js = None , sqlContext = None ,_itemid_list = [], _poiid_list = [],_type = 'ITEMID', _change_type = 'Not Found',use_db = False,multiplicity_check = False, itemidFrame = None, poiidFrame = None, config_ = None,debug = False):
     global globalVar
     #print('process start:'+timenow())
     logger = logging.getLogger("processing logger")
     logger.info("Loading mysql dictionary_status into memory for join and filter operation")
     # avoid the data loading for comparision
     # use hdfs to store last day data
     print('process start:' + timenow())
     verbosity = 1
     latest_file_number = 0
     # initializing stages
     itemid_list = []
     added_dates = {}
     added_bus   = {}
     empty_dataframe = sqlContext.createDataFrame(globalVar.spark_context.emptyRDD(),StructType([]))
     ################################################################################################
     latest_file_number = 0
     print "start of read time: " + str(timenow())
     string_ =  _type   if _change_type is 'Not Found' else _change_type
     print "read begins for " + string_
     if debug is True:
	     print "The amount of data system read: " + str(rdd.count())
     print('read-end ' + timenow())
     print "Limit the number of businesses"
     sets = set(config_.businessSets)
     print "End of business selection process"
     print "Get the header information: "
     #.filter(lambda x : (x.BUSINESS_ID in sets))
     #rdd.filter()
     try:
        df1 = rdd.rdd.map(lambda c: Row( ITEM_ID = int(c[0]), BUSINESS_ID = int(c[1]), SUBCATEGORY_NUMBER = int(c[2]), ITEM_NUMBER = int(c[3]),  ADDED_DATE = c[105], UPDATE_DATE = c[106], COUNTRY_CODE = int(c[112]), GROUP_ITEM_ID = int(c[113]), PARENT_ITEM_ID = int(c[114]), PARENT_ITEM_ID_STATUS = c[115], OUTLETITEM_MAP_CHANGE_DATE = c[116])).toDF() if _type is 'ITEMID' else rdd.rdd.map(lambda c: Row( POIID = c[0], BUSINESS_ID = c[1], ITEM_ID = c[20], POSOUTLET = c[2],  OUTLETBRAND = c[8], OUTLETITEMNUMBER = c[9], OUTLETDESCRIPTION = c[10], SKU = c[14], MANUFACTURERCODE = c[16], ADDED_DATE = c[26], UPDATE_DATE = c[27])).toDF()
     	#df1 = changeToDataFrame(rdd2)
	#df1.na.fill(-1)
	print "Remaining Total data after filtering by business: " + str( df1.count())
     except ValueError as v:
	print "value Error :" + str(v)
	print "Possible data Error exiting....."
	sys.exit(0)
        #Add a column for the 'duration'
     logger.info("Creating a time difference for itemid list")
     if 'POIID' in _type:
	print "verifying update and added date"
    	df1.select('POIID','UPDATE_DATE','ADDED_DATE').show()
     timeDiff = createTimeFormatting(timeFmt = "yyyy-mm-dd'T'HH:mm:ss.SSS", timeScale = 86400) if 'ITEMID' in _type else None
     logger.info("End of creating time difference for itemid list")
     if (timeDiff is  None and _type is 'ITEMID' ):		
	print "Application has a logic Error"
	print "Something wrong we need new add items to pull the records from history"
    	raise ValueError
	print ("We cannot determine new add without timeDiff value")
	sys.exit(0)
	#func_udf = udfFunction(createTimeFormatting, TimestampType()) if timeDiff is not None else None
     print "Start filtering out zero item ids"
     logger.info("start filtering out zero itemids")	
     df2 = filterOutItemidWithZero(df1)
     logger.info("end of filtering out zero itemids")
     print "End of filtering out zero item ids"
     #print "after removing itemid with zero value remaining items are :" + str(df2.count())
     df1 = df1.withColumn("Duration", timeDiff) if timeDiff is not None else df1
        #df1 = df1.withColumn("Duration",func_udf(df1['update_date'],df1['added_date'])) if func_udf is not None else df1
     df1 = df1.withColumn('UPDATE_DATE',df1.UPDATE_DATE.substr(0, 10)) if 'POIID' in _type else df1
     df1 = df1.withColumn("Duration", funcs.datediff('UPDATE_DATE','ADDED_DATE')) if 'POIID' in _type else df1
     if _type is 'POIID' or _type is 'ITEMID':
	df1.select('ADDED_DATE','UPDATE_DATE','Duration').show()
     printStr = "start detecting new adds for  poiids from posoutletitem table" if _type is "POIID" else "start detecting new add for itemids from positems"
     if _change_type is not "NewAddRemap" :
	print printStr
     else:
	print "Process of remaps records detection start now: "
     df2 = df1.filter(df1.Duration < config_.lagTime ) if ( len(_poiid_list) is 0 and _change_type is not "NewAddRemap")  else df1
     if len(_poiid_list) is 0 and _change_type is not "NewAddRemap":
	df1.unpersist()
     if len(_poiid_list) is 0:
        logger.debug("after filtering with respect to time remaining new records :" + str(df2.count()))
	df2 = df2.alias('df2').join(itemidFrame,df2.ITEM_ID == itemidFrame.ITEM_ID, 'inner').select('df2.*') if len(_itemid_list) is not 0 else df2 #.filter(df2.ITEM_ID.isin(_itemid_list)) if len(_itemid_list) is not 0 else df2 #filter out by adding ~ at beginning?
     if (_type is  "POIID"):
	logger.debug( "after filtering out with ITEMID remainging POIIDS " + str(df2.count()))
     print("Keep poiids for remap operation")
        # possible chance of error here
     if(_change_type is "NewAddRemap"):
	print "Filtering based on POIID"
        #df3 = df2.alias('df2').join(poiidFrame,df2.POIID == poiidFrame.POIID, 'inner').select("df2.*") if len(_poiid_list) is not 0 else df2 #.filter(~df2.POIID.isin(_poiid_list)) if len(_poiid_list) is not 0 else df2    #filter out by adding ~ at beginning?
     df3 = None
     alt = False
     if _type is 'POIID' and _change_type is 'NewAddRemap' and alt == True:
	df3 = df2.alias('df2').join(poiidFrame,df2.POIID == poiidFrame.POIID, 'inner').select("df2.*") 
	#df3 = df3.alias('df3').filter(df3.ITEM_ID.isin(_itemid_list) == False )#.select('df3.*')
	print "Filtering for newAdd remaps"
	logger.debug( "size of the poiid data frame: " + str(poiidFrame.count()))
	logger.debug("data frame three size should match with poiidFrame size " + str(df3.count()))
	logger.debug( "size of the total data before filtering: " + str(df2.count()))
	df2 = df2.alias('DF2').join(df3.alias('DF3') ,psf.col('DF2.POIID') == psf.col('DF3.POIID'),'leftanti')
       	df3.unpersist()
     if _type is 'POIID' and _change_type is 'NewAddRemap' and alt == False:
	#newAddPoiid = poiidFrame.collect()
	df2 = df2.filter(df2.POIID.isin(set(_poiid_list)) == False )
     print( 'collect()' + timenow())
	
     if  _type is "ITEMID" :
	try:
		df2 = df2.rdd.map(lambda x : Row(BUSINESS_ID = x.BUSINESS_ID, ITEM_ID = x.ITEM_ID, SUB_CATEGORY = x.SUBCATEGORY_NUMBER, ITEMNUMBER = x.ITEM_NUMBER,ADDED_DATE = x.ADDED_DATE,UPDATE_DATE =  x.UPDATE_DATE)).toDF()
	except ValueError as v:
		print "continue operation after empty itemid dataframe df2"
		logging.info("value error are: " + str(v)) 
		sys.exit(0)
     else:
	try:
		if use_db == True:
			df2 = df2.rdd.map(lambda x : Row(POSOUTLET = x.POSOUTLET , OUTLETBRAND = x.OUTLETBRAND,  OUTLETITEMNUMBER= x.OUTLETITEMNUMBER , OUTLETDESCRIPTION = x.OUTLETDESCRIPTION, SKU = x.SKU , UPC = x.MANUFACTURERCODE)).toDF() 
 		        df2 = df2.rdd.map(lambda x : Row(BUSINESS_ID = x.BUSINESS_ID, ITEM_ID = x.ITEM_ID,POIID = x.POIID,ADDED_DATE = x.ADDED_DATE,UPDATE_DATE =  x.UPDATE_DATE ))
		else:
			df2 = df2.rdd.map(lambda x : Row(POSOUTLET = x.POSOUTLET , OUTLETBRAND = x.OUTLETBRAND,  OUTLETITEMNUMBER= x.OUTLETITEMNUMBER , OUTLETDESCRIPTION = x.OUTLETDESCRIPTION, SKU = x.SKU  , UPC = x.MANUFACTURERCODE ,BUSINESS_ID = x.BUSINESS_ID, ITEM_ID = x.ITEM_ID,POIID = x.POIID,ADDED_DATE = x.ADDED_DATE,UPDATE_DATE =  x.UPDATE_DATE )).toDF()
			#df2 = df2.toDF() #sqlContext.createDataFrame(df3)
			df2 = df2.withColumn("UPC",df2["UPC"].cast("long"))
	except ValueError as v:
		print "continue operation after empty dataframe for poiid df2 "
		logging.info("value error are: " + str(v)) 
		sys.exit(0)
     ###################################################################
     print("Adding four additional columns for later use")
     df2 = df2.withColumn('FINDSTATUS_END',lit(time.strftime('%Y-%m-%d %H-%M-%S')))
     df2 = df2.withColumn('ITEM_TYPE', lit(_type))
     df2 = df2.withColumn('CHANGE_TYPE', lit(_change_type))
     #df2 = df2.withColumn('FILE', lit(filename))
     df2 = df2.withColumn('LATESTADDFLAG',lit(1))
     logger.info("End of adding columns containg meta information")
     print("End of adding columns")
     #############################################################################
     #if use_db == True:
	#df2.write.jdbc(url='jdbc:mysql://lslhdpcd1:3306/PACEDICTIONARY?serverTimezone=UTC',table='DICTIONARY_STATUS',mode='append',properties={'user':'root','password':'My$qlD','driver':'com.mysql.jdbc.Driver'})
    ################################################################
     mydict = df2.toPandas().to_dict(orient = 'list')
     print "extend the list with new items"
     itemid_list = mydict['ITEM_ID'] if 'ITEMID' in _type else mydict['POIID']
     print("End of extending list")
    #print(str(_type)+' operation is done: ' + timenow())
     print("Lenght of " + str(_type) + " type list " + str(len(itemid_list)))
     return itemid_list, latest_file_number, df2

