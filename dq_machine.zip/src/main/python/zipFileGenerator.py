#!/usr/bin/env python
import os
import zipfile

def zipdir(path,ziph):
    for root,dirs,files in os.walk(path):
        for filing in files:
                ziph.write(os.path.join(root,filing))
    return

if __name__ == '__main__':
        zipf = zipfile.ZipFile('dq_machine.zip','w',zipfile.ZIP_DEFLATED)
        zipdir('dqMachine',zipf)
        zipf.close()
